tellraw @s {"color":"gray","italic":true,"translate":"두번째 수수께끼를 해결했습니다..."}

scoreboard players set @s bac_third_line_horse 0
scoreboard players set @s bac_third_line_pig 0
scoreboard players set @s bac_third_line_strider 0
scoreboard players set @s bac_third_line_happy_ghast 0
scoreboard players set @s bac_third_line_nautilus 0