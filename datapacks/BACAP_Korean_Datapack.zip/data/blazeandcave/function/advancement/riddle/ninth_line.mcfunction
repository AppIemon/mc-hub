tellraw @s {"color":"gray","italic":true,"translate":"아홉번째 수수께끼를 해결했습니다..."}

tellraw @s {"color":"gold","text":" +1 ","extra":[{"translate":"수수께끼의 두루마리"}]}

give @s paper[minecraft:enchantment_glint_override=true,minecraft:item_name={"color":"white","translate":"수수께끼의 두루마리"},minecraft:lore=[{"color":"gray","italic":true,"translate":"뒤틀린 버튼을 1,000번 설치하세요"},{"color":"gray","italic":true,"translate":"이 두루마리는 1,000번째로 추가된 아이템 보상입니다"},{"color":"gray","italic":true,"translate":"또한 이 발전 과제는 1,000번째로 추가된 발전 과제입니다"}]]