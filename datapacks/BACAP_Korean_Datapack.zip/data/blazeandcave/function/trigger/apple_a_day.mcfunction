tellraw @s {"text":"                                             ","color":"dark_gray","strikethrough":true}

execute if score @s bac_apple_days matches 0.. run tellraw @s {"translate":"You have eaten an apple every day for","extra":[{"text":" "},{"color":"gold","score":{"name":"@s","objective":"bac_apple_days"}},{"text":" "},{"translate":"days."}]}

execute if entity @s[advancements={blazeandcave:technical/consume_apple=true}] run tellraw @s {"color":"green","translate":"오늘은 이미 사과를 먹었습니다"}
execute if entity @s[advancements={blazeandcave:technical/consume_apple=false}] run tellraw @s {"color":"red","translate":"오늘은 아직 사과를 먹지 않았습니다."}
tellraw @s {"color":"gray","italic":true,"text":""}
tellraw @s {"color":"gray","italic":true,"translate":"잠을 자서 하루가 넘어갔는데도 사과를 먹었다고 표시되면, 10초 후에 다시 시도해주세요."}

tellraw @s {"text":"                                             ","color":"dark_gray","strikethrough":true}

scoreboard players set @s bac_apple_a_day 0
