tellraw @s {"text":"                                             ","color":"dark_gray","strikethrough":true}
tellraw @s {"color":"gray","translate":"통계 진행도"}
tellraw @s {"text":"                                             ","color":"dark_gray","strikethrough":true}

execute if score @s bac_day_count matches 0.. run tellraw @s {"color":"white","translate":"플레이한 일수","extra":[{"text":" "},{"color":"gold","score":{"name":"@s","objective":"bac_day_count"}}]}
execute if score @s bac_stat_food matches 0.. run tellraw @s {"color":"white","translate":"먹은 음식 개수","extra":[{"text":" "},{"color":"gold","score":{"name":"@s","objective":"bac_stat_food"}}]}
execute if score @s bac_stat_loot_chest matches 0.. run tellraw @s {"color":"white","translate":"연 노획물 상자 개수","extra":[{"text":" "},{"color":"gold","score":{"name":"@s","objective":"bac_stat_loot_chest"}}]}

function #bacap_fanpacks:statistics_trigger

tellraw @s {"text":"                                             ","color":"dark_gray","strikethrough":true}

scoreboard players set @s bac_statistics 0
