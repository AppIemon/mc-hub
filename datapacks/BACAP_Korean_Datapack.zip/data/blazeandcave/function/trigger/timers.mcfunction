tellraw @s {"text":"                                             ","color":"dark_gray","strikethrough":true}
tellraw @s {"color":"gray","translate":"타이머 진척도"}
tellraw @s {"color":"gray","italic":true,"translate":"숫자는 초 단위입니다"}
tellraw @s {"color":"gray","italic":true,"translate":"1200초 = 인게임 1일"}
tellraw @s {"text":"                                             ","color":"dark_gray","strikethrough":true}

execute if score @s bac_let_me_out matches 1.. run tellraw @s {"color":"white","translate":"Let Me Out","extra":[{"text":": "},{"color":"gold","score":{"name":"@s","objective":"bac_let_me_out"}}]}
execute if score @s bac_i_yearned_for_the_mines matches 1.. run tellraw @s {"color":"white","translate":"동굴은 나의 집","extra":[{"text":": "},{"color":"gold","score":{"name":"@s","objective":"bac_i_yearned_for_the_mines"}}]}
execute if score @s bac_castaway matches 1.. run tellraw @s {"color":"white","translate":"캐스트 어웨이","extra":[{"text":": "},{"color":"gold","score":{"name":"@s","objective":"bac_castaway"}}]}
execute if score @s bac_just_keep matches 1.. run tellraw @s {"color":"white","translate":"에너자이저","extra":[{"text":": "},{"color":"gold","score":{"name":"@s","objective":"bac_just_keep"}}]}
execute if score @s bac_underwater matches 1.. run tellraw @s {"color":"white","translate":"인어","extra":[{"text":": "},{"color":"gold","score":{"name":"@s","objective":"bac_underwater"}}]}
execute if score @s bac_captain_america matches 1.. run tellraw @s {"color":"white","translate":"냉동 인간","extra":[{"text":": "},{"color":"gold","score":{"name":"@s","objective":"bac_captain_america"}}]}
execute if score @s bac_hh_life matches 1.. run tellraw @s {"color":"white","translate":"하프라이프","extra":[{"text":": "},{"color":"gold","score":{"name":"@s","objective":"bac_hh_life"}}]}

function #bacap_fanpacks:timers_trigger

tellraw @s {"text":"                                             ","color":"dark_gray","strikethrough":true}

scoreboard players set @s bac_timers 0
