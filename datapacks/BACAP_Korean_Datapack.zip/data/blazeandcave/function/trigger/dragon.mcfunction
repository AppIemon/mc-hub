tellraw @s {"text":"                                             ","color":"dark_gray","strikethrough":true}

execute unless score @s bac_dvd matches 1 unless score @s bac_dvd2eb matches 1 unless score @s bac_dveps matches 1 run tellraw @s {"color":"red","translate":"현재 '용용 죽겠지', '산전수전 공중전', '세계관 최강자들의 싸움' 발전 과제를 달성할 수 없습니다"}
execute unless score @s bac_dvd matches 1 unless score @s bac_dvd2eb matches 1 unless score @s bac_dveps matches 1 run tellraw @s {"color":"gray","italic":true,"translate":"만약 엔더 드래곤이나 위더를 소환 중에 있다면, 빨리 날아오르세요!"}

execute if score @s bac_dveps matches 1 if score @s bac_withercool matches 1.. run tellraw @s {"color":"red","translate":"현재 '용용 죽겠지', '산전수전 공중전', '세계관 최강자들의 싸움' 발전 과제를 달성할 수 없습니다"}
execute if score @s bac_dveps matches 1 if score @s bac_withercool matches 1.. run tellraw @s {"color":"gray","italic":true,"translate":"만약 엔더 드래곤이나 위더를 소환 중에 있다면, 빨리 날아오르세요!"}

execute if score @s bac_dvd matches 1 unless score @s bac_dvd2eb matches 1 run tellraw @s {"color":"green","translate":"현재 '용용 죽겠지' 발전 과제를 달성할 수 있습니다. 드래곤 머리를 벗지 말고 엔더 드래곤을 무찌르세요!"}
execute if score @s bac_dvd2eb matches 1 run tellraw @s {"color":"green","translate":"현재 '산전수전 공중전' 발전 과제를 달성할 수 있습니다. 드래곤 머리를 벗지 말고, 땅에 닿지 않게 조심하면서 엔더 드래곤을 무찌르세요!"}
execute if score @s bac_dveps matches 1 unless score @s bac_withercool matches 1.. run tellraw @s {"color":"green","translate":"현재 '세계관 최강자들의 싸움' 발전 과제를 달성할 수 있습니다. 드래곤 머리를 벗지 말고, 땅에 닿지 않게 조심하면서 위더를 무찌르세요!"}

tellraw @s {"text":"                                             ","color":"dark_gray","strikethrough":true}

scoreboard players set @s bac_dragon 0
