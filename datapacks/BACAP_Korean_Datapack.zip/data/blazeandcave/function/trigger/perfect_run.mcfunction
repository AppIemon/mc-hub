tellraw @s {"text":"                                             ","color":"dark_gray","strikethrough":true}

execute if entity @s[advancements={blazeandcave:challenges/the_perfect_run=false,blazeandcave:technical/spawn_perfect_one=false}] run tellraw @s {"color":"red","translate":"현재 '퍼펙트 런' 발전 과제를 달성할 수 없습니다"}

execute if entity @s[advancements={blazeandcave:challenges/the_perfect_run=false,blazeandcave:technical/spawn_perfect_one=true,blazeandcave:technical/spawn_perfect_all=false}] run tellraw @s {"translate":"현재 '퍼펙트 런'의 준비 단계에 있습니다. 시작하기까지 %1$s초 남았습니다!","with":[{"color":"gold","score":{"name":"@s","objective":"bac_pr_tl"}}]}
execute if entity @s[advancements={blazeandcave:challenges/the_perfect_run=false,blazeandcave:technical/spawn_perfect_one=true,blazeandcave:technical/spawn_perfect_all={dragon=false}}] run tellraw @s {"color":"gray","italic":true,"translate":"엔더 드래곤이 아직 소환되지 않았습니다. 엔더 드래곤 보스바가 나타나면 측정됩니다."}
execute if entity @s[advancements={blazeandcave:challenges/the_perfect_run=false,blazeandcave:technical/spawn_perfect_one=true,blazeandcave:technical/spawn_perfect_all={wither=false}}] run tellraw @s {"color":"gray","italic":true,"translate":"위더가 아직 소환되지 않았습니다. 소환 즉시 측정됩니다."}
execute if entity @s[advancements={blazeandcave:challenges/the_perfect_run=false,blazeandcave:technical/spawn_perfect_one=true,blazeandcave:technical/spawn_perfect_all={raid=false}}] run tellraw @s {"color":"gray","italic":true,"translate":"습격이 아직 시작되지 않았습니다. 습격 보스바가 나타나면 측정됩니다."}

execute if entity @s[advancements={blazeandcave:challenges/the_perfect_run=false,blazeandcave:technical/spawn_perfect_all=true}] run tellraw @s {"color":"green","translate":"현재 '퍼펙트 런' 발전 과제를 달성할 수 있습니다"}
execute if entity @s[advancements={blazeandcave:challenges/the_perfect_run=false,blazeandcave:technical/spawn_perfect_all=true}] run tellraw @s {"translate":"대미지를 받지 않고 전부 끝내버리세요"}
execute if entity @s[advancements={blazeandcave:challenges/the_perfect_run=false,blazeandcave:technical/spawn_perfect_all=true,blazeandcave:challenges/the_perfect_run={dragon=false}}] run tellraw @s {"text":" ","extra":[{"color":"gray","translate":"entity.minecraft.ender_dragon"}]}
execute if entity @s[advancements={blazeandcave:challenges/the_perfect_run=false,blazeandcave:technical/spawn_perfect_all=true,blazeandcave:challenges/the_perfect_run={wither=false}}] run tellraw @s {"text":" ","extra":[{"color":"gray","translate":"entity.minecraft.wither"}]}
execute if entity @s[advancements={blazeandcave:challenges/the_perfect_run=false,blazeandcave:technical/spawn_perfect_all=true,blazeandcave:challenges/the_perfect_run={raid=false}}] run tellraw @s {"text":" ","extra":[{"color":"gray","translate":"event.minecraft.raid"}]}

execute if entity @s[advancements={blazeandcave:challenges/the_perfect_run=true}] run tellraw @s {"color":"gold","translate":"이미 '퍼펙트 런'을 달성했습니다. 수고하셨어요!"}

tellraw @s {"text":"                                             ","color":"dark_gray","strikethrough":true}

scoreboard players set @s bac_perfect_run 0
