tellraw @a {"color":"dark_gray","text":"-|-|-|- ","extra":[{"color":"gold","bold":true,"translate":"개발자를 위한 메시지"},{"color":"dark_gray","text":" -|-|-|-"}]}
tellraw @a {"color":"yellow","bold":false,"translate":"이 팩은 다음 마인크래프트 대형 업데이트의 스냅샷을 위해 만들어진 베타 빌드 버전입니다."}
tellraw @a {"color":"yellow","bold":false,"translate":"이 버전은 기능들이 정상적으로 작동하며 플레이하는 데 문제 없지만, 가끔 몇몇 버그나 문제가 발생할 수 있습니다."}
tellraw @a {"color":"yellow","bold":false,"translate":"양해 부탁드립니다."}