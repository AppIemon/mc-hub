tellraw @s {"color":"dark_gray","text":"-|-|-|- ","extra":[{"color":"green","bold":true,"translate":"어서오세요!"},{"color":"dark_gray","text":" -|-|-|-"}]}
tellraw @s {"color":"#D1FFFD","bold":false,"translate":"이 월드에는 ","extra":[{"color":"yellow","bold":true,"translate":"Blaze"},{"color":"gray","bold":true,"translate":"and"},{"color":"aqua","bold":true,"translate":"Cave"},{"color":"gray","bold":true,"translate":"의 발전 과제 데이터팩"}]}
tellraw @s {"color":"white","italic":true,"translate":"제작: ","extra":[{"color":"gold","italic":true,"underlined":false,"text":"Cavinator1","click_event":{"action":"open_url","url":"https://www.planetminecraft.com/member/cavinator1/"}}]}
tellraw @s {"text":" "}
tellraw @s {"color":"#D1FFFD","italic":false,"translate":"당신이 원한다면, 제","extra":[{"text":" "},{"color":"blue","italic":false,"underlined":true,"translate":"디스코드","click_event":{"action":"open_url","url":"https://discord.gg/GBMSmWg"}},{"text":" "},{"translate":"로 놀러오세요!"}]}
