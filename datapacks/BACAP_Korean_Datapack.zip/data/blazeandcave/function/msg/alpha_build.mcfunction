tellraw @a {"color":"dark_gray","text":"-|-|-|- ","extra":[{"color":"gold","bold":true,"translate":"개발자를 위한 메시지"},{"color":"dark_gray","text":" -|-|-|-"}]}
tellraw @a {"color":"yellow","bold":false,"translate":"이 팩은 다음 마인크래프트 대형 업데이트의 스냅샷을 위해 만들어진 알파 빌드 버전입니다."}
tellraw @a {"color":"yellow","bold":false,"translate":"이 팩에 포함된 새로운 발전 과제는 테스트용이며, 아직 보상 기능이 없습니다."}
tellraw @a {"color":"yellow","bold":false,"translate":"즉, 그 발전 과제들은 아직 발전 과제 해금 메시지 설정, 발전 과제 스코어보드, 협동 모드 설정에 해당되지 않습니다."}
tellraw @a {"color":"yellow","bold":false,"translate":"위 기능들은 마인크래프트 스냅샷이 버그 수정이 대부분인 시기 또는 프리 릴리즈일 때 데이터팩이 베타 빌드 버전으로 업데이트 되면서 추가될 것입니다."}
tellraw @a {"color":"yellow","bold":false,"translate":"양해 부탁드립니다."}