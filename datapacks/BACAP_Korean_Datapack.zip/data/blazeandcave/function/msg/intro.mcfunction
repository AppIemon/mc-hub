tellraw @s {"color":"dark_gray","text":"-|-|-|- ","extra":[{"color":"green","bold":true,"translate":"어서오세요!"},{"color":"dark_gray","text":" -|-|-|-"}]}
tellraw @s {"color":"#D1FFFD","bold":false,"translate":"다운로드해주셔서 감사합니다","extra":[{"text":"\n"},{"color":"yellow","bold":true,"translate":"Blaze"},{"color":"gray","bold":true,"translate":"and"},{"color":"aqua","bold":true,"translate":"Cave"},{"color":"gray","bold":true,"translate":"의 발전 과제 데이터팩"}]}
tellraw @s {"text":" "}
tellraw @s {"color":"#D1FFFD","italic":false,"translate":"만약 설정을 변경하고 싶으시다면, 다음 명령어를 사용하세요:"}
tellraw @s {"color":"aqua","italic":false,"translate":"","extra":[{"text":" "},{"text":"/function blazeandcave:config_menu","click_event":{"action":"suggest_command","command":"/function blazeandcave:config_menu"}}]}
tellraw @s {"text":" "}
tellraw @s {"color":"#D1FFFD","italic":false,"translate":"데이터팩에 대한 최신 정보를 알고 싶으신가요? 제","extra":[{"text":" "},{"color":"blue","italic":false,"underlined":true,"translate":"디스코드","click_event":{"action":"open_url","url":"https://discord.gg/GBMSmWg"}},{"text":" "},{"translate":"에 가입한 뒤 #roles 채널에서 Advancement Pack Squad가 되세요!"}]}

scoreboard players set introduced bac_settings 1