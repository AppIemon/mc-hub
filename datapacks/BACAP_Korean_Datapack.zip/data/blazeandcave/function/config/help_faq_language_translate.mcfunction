tellraw @s {"text":"                                             ","color":"dark_gray","strikethrough":true}
tellraw @s {"color":"gray","bold":false,"text":" ","extra":[{"color":"gray","bold":false,"translate":"번역을 하고 싶은데 어떻게 해야 하나요?"}]}

tellraw @s {"text":"                                             ","color":"dark_gray","strikethrough":true}

# How
tellraw @s ["",{"translate":"언어 팩을 다운로드하고 압축을 푼 뒤, base_language_file.json 파일을 찾아 엽니다"}]
tellraw @s ["",{"translate":"번역을 하기 위해선 다음을 따라야 합니다"}]
tellraw @s ["",{"translate":"번역을 마치면 Planet Minecraft나 디스코드에서 Cavinator1에게 번역 파일을 보냅니다. 향후 업데이트에서 추가될 겁니다!"}]
tellraw @s ["",{"translate":"당신의 이름이 번역자 명단에 오를 것입니다"}]

# Go back
tellraw @s {"text":"                                             ","color":"dark_gray","strikethrough":true}
tellraw @s ["",{"text":"[ «« ]","color":"red","click_event":{"action":"run_command","command":"/function blazeandcave:config/help_faq"},"hover_event":{"action":"show_text","value":["",{"translate":"클릭하여 돌아가기","color":"gold"}]}}," ",{"translate":"돌아가기"}]

tellraw @s {"text":"                                             ","color":"dark_gray","strikethrough":true}
