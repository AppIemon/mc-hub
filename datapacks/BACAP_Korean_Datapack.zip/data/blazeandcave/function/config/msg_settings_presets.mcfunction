tellraw @s {"text":"                                             ","color":"dark_gray","strikethrough":true}
tellraw @s {"color":"gray","bold":false,"text":" ","extra":[{"color":"gray","bold":false,"translate":"메시지 프리셋"}]}

tellraw @s {"text":"                                             ","color":"dark_gray","strikethrough":true}

# Preset settings
tellraw @s ["",{"text":"[ »» ]","color":"green","click_event":{"action":"run_command","command":"/function blazeandcave:config/msg_set_on"},"hover_event":{"action":"show_text","value":["",{"translate":"클릭하여 설정","color":"gold"}]}}," ",{"translate":"해금 메시지 켜기"}]
tellraw @s ["",{"text":"[ »» ]","color":"red","click_event":{"action":"run_command","command":"/function blazeandcave:config/msg_set_off"},"hover_event":{"action":"show_text","value":["",{"translate":"클릭하여 설정","color":"gold"}]}}," ",{"translate":"해금 메시지 끄기"}]
tellraw @s ["",{"text":"[ »» ]","color":"yellow","click_event":{"action":"run_command","command":"/function blazeandcave:config/msg_set_first"},"hover_event":{"action":"show_text","value":["",{"translate":"클릭하여 설정","color":"gold"}]}}," ",{"translate":"처음 해금한 사람으로 해금 메시지 설정(협동 모드에서 사용하는 것을 추천합니다)"}]
tellraw @s ["",{"text":"[ »» ]","color":"aqua","click_event":{"action":"run_command","command":"/function blazeandcave:config/msg_set_first_team"},"hover_event":{"action":"show_text","value":["",{"translate":"클릭하여 설정","color":"gold"}]}}," ",{"translate":"모든 메시지를 팀에서 발전 과제를 처음으로 해금한 사람으로 설정합니다(팀 협동 모드에서 권장합니다)"}]
tellraw @s ["",{"text":"[ »» ]","color":"dark_green","click_event":{"action":"run_command","command":"/function blazeandcave:config/msg_set_server1"},"hover_event":{"action":"show_text","value":["",{"translate":"클릭하여 설정","color":"gold"}]}}," ",{"translate":"일반 과제 제외"}]
tellraw @s ["",{"text":"[ »» ]","color":"dark_green","click_event":{"action":"run_command","command":"/function blazeandcave:config/msg_set_server2"},"hover_event":{"action":"show_text","value":["",{"translate":"클릭하여 설정","color":"gold"}]}}," ",{"translate":"일반, 목표 과제 제외"}]
tellraw @s ["",{"text":"[ »» ]","color":"blue","click_event":{"action":"run_command","command":"/function blazeandcave:config/msg_set_vanilla_msg"},"hover_event":{"action":"show_text","value":["",{"translate":"클릭하여 설정","color":"gold"}]}}," ",{"translate":"기본 메시지 켜기(DiscordSRV 같은 플러그인을 사용하는 서버에서 권장합니다)"}]

tellraw @s {"text":"                                             ","color":"dark_gray","strikethrough":true}

# Go back
tellraw @s ["",{"text":"[ «« ]","color":"red","click_event":{"action":"run_command","command":"/function blazeandcave:config/msg_settings"},"hover_event":{"action":"show_text","value":["",{"translate":"클릭하여 돌아가기","color":"gold"}]}}," ",{"translate":"돌아가기"}]

tellraw @s {"text":"                                             ","color":"dark_gray","strikethrough":true}
