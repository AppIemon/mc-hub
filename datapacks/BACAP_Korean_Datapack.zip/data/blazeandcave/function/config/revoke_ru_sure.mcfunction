# Asks "Are you sure?"

tellraw @s {"text":"                                             ","color":"dark_gray","strikethrough":true}
tellraw @s [" ",{"color":"yellow","translate":"정말입니까?"}]
tellraw @s {"text":"                                             ","color":"dark_gray","strikethrough":true}
tellraw @s [" ",{"color":"red","translate":"한번 철회된 발전 과제는 복구할 수 없습니다"}]
tellraw @s [" ",{"color":"gold","translate":"몇몇 통계 발전 과제는 다시 해금될 수 있습니다. 이것들까지 초기화하길 원한다면 플레이어의 통계 파일을 직접 삭제해야 합니다"}]
tellraw @s {"text":"                                             ","color":"dark_gray","strikethrough":true}
tellraw @s [" ",{"translate":"어떤 플레이어의 발전 과제를 철회할 지 선택하세요"}]
tellraw @s {"text":"                                             ","color":"dark_gray","strikethrough":true}

tellraw @s ["",{"translate":"[ »» ]","color":"green","click_event":{"action":"run_command","command":"/function blazeandcave:config/revoke_yourself"},"hover_event":{"action":"show_text","value":["",{"translate":"클릭하여 확인","color":"gold"}]}}," ",{"translate":"자신"}]
tellraw @s ["",{"translate":"[ »» ]","color":"yellow","click_event":{"action":"run_command","command":"/function blazeandcave:config/revoke_closest"},"hover_event":{"action":"show_text","value":["",{"translate":"클릭하여 확인","color":"gold"}]}}," ",{"translate":"자신과 가장 가까운 플레이어"}]
tellraw @s ["",{"translate":"[ »» ]","color":"dark_red","click_event":{"action":"run_command","command":"/function blazeandcave:config/revoke_everyone"},"hover_event":{"action":"show_text","value":["",{"translate":"클릭하여 확인","color":"gold"}," ",{"translate":">:)","color":"gold"}]}}," ",{"translate":"모든 플레이어!! (접속 중인)"}]

tellraw @s {"text":"                                             ","color":"dark_gray","strikethrough":true}

# Go back I want to be MONKE
tellraw @s ["",{"text":"[ «« ]","color":"red","click_event":{"action":"run_command","command":"/function blazeandcave:config/technical_settings"},"hover_event":{"action":"show_text","value":["",{"translate":"클릭하여 돌아가기","color":"gold"}]}}," ",{"translate":"돌아가기"}]

tellraw @s {"text":"                                             ","color":"dark_gray","strikethrough":true}