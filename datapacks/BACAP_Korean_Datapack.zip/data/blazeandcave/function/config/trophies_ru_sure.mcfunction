# Asks "Are you sure?"

tellraw @s {"text":"                                             ","color":"dark_gray","strikethrough":true}
tellraw @s [" ",{"color":"yellow","translate":"정말입니까?"}]
tellraw @s {"text":"                                             ","color":"dark_gray","strikethrough":true}
tellraw @s [" ",{"color":"red","translate":"트로피 업데이트를 하기 전의 월드에서 사용해주세요, 이 기능은 이미 달성한 발전 과제의 트로피를 못 받은 경우에 사용할 수 있게 만든 것입니다"}]
tellraw @s [" ",{"translate":"모두의 인벤토리에 여유 공간이 있는지 확인한 뒤 결정해주세요"}]
tellraw @s {"text":"                                             ","color":"dark_gray","strikethrough":true}

tellraw @s ["",{"translate":"[ 예 ]","color":"green","click_event":{"action":"run_command","command":"/function blazeandcave:config/trophies_begin_grant"},"hover_event":{"action":"show_text","value":["",{"translate":"클릭하여 확인","color":"gold"}]}}," ",{"translate":"[ 아니오 ]","color":"red","click_event":{"action":"run_command","command":"/function blazeandcave:config/technical_settings"},"hover_event":{"action":"show_text","value":["",{"translate":"클릭하여 돌아가기","color":"gold"}]}}]