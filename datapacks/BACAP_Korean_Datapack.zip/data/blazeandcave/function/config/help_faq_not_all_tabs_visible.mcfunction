tellraw @s {"text":"                                             ","color":"dark_gray","strikethrough":true}
tellraw @s {"color":"gray","bold":false,"text":" ","extra":[{"color":"gray","bold":false,"translate":"왜 모든 탭이 보이지 않나요?"}]}

tellraw @s {"text":"                                             ","color":"dark_gray","strikethrough":true}

# How
tellraw @s ["",{"translate":"각 탭에 속하는 발전 과제를 하나라도 달성하지 못하면 탭은 보이지 않습니다"}]
tellraw @s ["",{"translate":"대부분의 대표 발전 과제는 달성하기 쉽지만,"}]
tellraw @s ["",{"translate":"극한 과제 탭은 엔더 드래곤을 처치하기 전까진 보이지 않습니다"}]

# Go back
tellraw @s {"text":"                                             ","color":"dark_gray","strikethrough":true}
tellraw @s ["",{"text":"[ «« ]","color":"red","click_event":{"action":"run_command","command":"/function blazeandcave:config/help_faq"},"hover_event":{"action":"show_text","value":["",{"translate":"클릭하여 돌아가기","color":"gold"}]}}," ",{"translate":"돌아가기"}]

tellraw @s {"text":"                                             ","color":"dark_gray","strikethrough":true}
