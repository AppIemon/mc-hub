tellraw @s {"text":"                                             ","color":"dark_gray","strikethrough":true}
tellraw @s {"color":"gray","bold":false,"text":" ","extra":[{"color":"yellow","bold":false,"translate":"스코어보드를 어디에 표시할까요?"}]}

tellraw @s {"text":"                                             ","color":"dark_gray","strikethrough":true}

# Scoreboards
tellraw @s ["",{"text":"[ »» ]","color":"green","click_event":{"action":"run_command","command":"/scoreboard objectives setdisplay list bac_advancements_points"}}," ",{"translate":"탭 리스트"}]
tellraw @s ["",{"text":"[ »» ]","color":"green","click_event":{"action":"run_command","command":"/scoreboard objectives setdisplay sidebar bac_advancements_points"}}," ",{"translate":"사이드바"}]
tellraw @s ["",{"text":"[ »» ]","color":"green","click_event":{"action":"run_command","command":"/scoreboard objectives setdisplay below_name bac_advancements_points"}}," ",{"translate":"닉네임 아래"}]

tellraw @s {"text":"                                             ","color":"dark_gray","strikethrough":true}

# Go back
tellraw @s ["",{"text":"[ «« ]","color":"red","click_event":{"action":"run_command","command":"/function blazeandcave:config/scoreboard_settings"},"hover_event":{"action":"show_text","value":["",{"translate":"클릭하여 돌아가기","color":"gold"}]}}," ",{"translate":"돌아가기"}]

tellraw @s {"text":"                                             ","color":"dark_gray","strikethrough":true}
