tellraw @s {"text":"                                             ","color":"dark_gray","strikethrough":true}
tellraw @s {"color":"gray","bold":false,"text":" ","extra":[{"color":"gray","bold":false,"translate":"발전 과제 해금 메시지 설정"}]}

tellraw @s {"text":"                                             ","color":"dark_gray","strikethrough":true}

function blazeandcave:config/msg_settings_tiers


tellraw @s {"text":"                                             ","color":"dark_gray","strikethrough":true}
# Preset settings
tellraw @s ["",{"text":"[ »» ]","color":"light_purple","click_event":{"action":"run_command","command":"/function blazeandcave:config/msg_settings_presets"},"hover_event":{"action":"show_text","value":["",{"translate":"클릭하여 보기","color":"gold"}]}}," ",{"translate":"프리셋 보기"}]

tellraw @s {"text":"                                             ","color":"dark_gray","strikethrough":true}

# Go back
tellraw @s ["",{"text":"[ «« ]","color":"red","click_event":{"action":"run_command","command":"/function blazeandcave:config"},"hover_event":{"action":"show_text","value":["",{"translate":"클릭하여 돌아가기","color":"gold"}]}}," ",{"translate":"메인 메뉴로 돌아가기"}]

tellraw @s {"text":"                                             ","color":"dark_gray","strikethrough":true}
