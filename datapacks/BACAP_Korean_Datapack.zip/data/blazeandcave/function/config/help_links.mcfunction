tellraw @s {"text":"                                             ","color":"dark_gray","strikethrough":true}
tellraw @s {"color":"gray","bold":false,"text":" ","extra":[{"color":"gray","bold":false,"translate":"중요 링크"}]}

tellraw @s {"text":"                                             ","color":"dark_gray","strikethrough":true}

## Specifically: Language Pack, Hardcore and Terralith versions, Advancements Documentation, Trophy List, Discord and Patreon

# Link to Language Pack
tellraw @s ["",{"text":"[ »» ]","color":"aqua","click_event":{"action":"open_url","url":"https://bit.ly/37oaOop"},"hover_event":{"action":"show_text","value":["",{"translate":"클릭하여 링크 열기","color":"gold"}]}}," ",{"translate":"언어 팩","hover_event":{"action":"show_text","value":["",{"translate":"언어 팩은 발전 과제와 트로피들을 다른 언어로 번역한 리소스팩입니다","color":"#D1FFFD"}]}}]

# Link to Hardcore Version
tellraw @s ["",{"text":"[ »» ]","color":"red","click_event":{"action":"open_url","url":"https://bit.ly/3wR45xi"},"hover_event":{"action":"show_text","value":["",{"translate":"클릭하여 링크 열기","color":"gold"}]}}," ",{"translate":"하드코어 버전","hover_event":{"action":"show_text","value":["",{"translate":"하드코어 버전은 하드코어 모드에서 데이터팩을 완료할 수 있도록 하는 데이터팩입니다","color":"#D1FFFD"}]}}]

# Link to Terralith Version
tellraw @s ["",{"text":"[ »» ]","color":"dark_green","click_event":{"action":"open_url","url":"https://bit.ly/3JsMjUH"},"hover_event":{"action":"show_text","value":["",{"translate":"클릭하여 링크 열기","color":"gold"}]}}," ",{"translate":"테라리스 버전","hover_event":{"action":"show_text","value":["",{"translate":"테라리스 버전은 Starmute의 Teralith 데이터팩에 대한 발전 과제를 추가한 데이터팩입니다","color":"#D1FFFD"}]}}]

# Link to Advancements Docmentation
tellraw @s ["",{"text":"[ »» ]","color":"yellow","click_event":{"action":"open_url","url":"https://bit.ly/bacap_1_18_doc"},"hover_event":{"action":"show_text","value":["",{"translate":"클릭하여 링크 열기","color":"gold"}]}}," ",{"translate":"발전 과제 설명서","hover_event":{"action":"show_text","value":["",{"translate":"각 발전 과제에 대한 세부적인 설명을 적어놓은 문서입니다","color":"#D1FFFD"}]}}]

# Link to Trophy List
tellraw @s ["",{"text":"[ »» ]","color":"gold","click_event":{"action":"open_url","url":"https://bit.ly/3ekjf76"},"hover_event":{"action":"show_text","value":["",{"translate":"클릭하여 링크 열기","color":"gold"}]}}," ",{"translate":"트로피 목록","hover_event":{"action":"show_text","value":["",{"translate":"데이터팩 속 모든 트로피들에 대한 문서입니다","color":"#D1FFFD"}]}}]

# Link to Discord
tellraw @s ["",{"text":"[ »» ]","color":"blue","click_event":{"action":"open_url","url":"https://discord.gg/GBMSmWg"},"hover_event":{"action":"show_text","value":["",{"translate":"클릭하여 링크 열기","color":"gold"}]}}," ",{"translate":"디스코드"}]

# Link to Patreon
tellraw @s ["",{"text":"[ »» ]","color":"green","click_event":{"action":"open_url","url":"https://www.patreon.com/Cavinator1"},"hover_event":{"action":"show_text","value":["",{"translate":"클릭하여 링크 열기","color":"gold"}]}}," ",{"translate":"패트리온"}]

# Go back
tellraw @s {"text":"                                             ","color":"dark_gray","strikethrough":true}
tellraw @s ["",{"text":"[ «« ]","color":"red","click_event":{"action":"run_command","command":"/function blazeandcave:config/help_menu"},"hover_event":{"action":"show_text","value":["",{"translate":"클릭하여 돌아가기","color":"gold"}]}}," ",{"translate":"메인 메뉴로 돌아가기"}]

tellraw @s {"text":"                                             ","color":"dark_gray","strikethrough":true}
