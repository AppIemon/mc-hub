tellraw @s {"text":"                                             ","color":"dark_gray","strikethrough":true}
tellraw @s {"color":"gray","bold":false,"text":" ","extra":[{"color":"gray","bold":false,"translate":"플레이어를 팀에 추가하는 방법"}]}

tellraw @s {"text":"                                             ","color":"dark_gray","strikethrough":true}

# How
tellraw @s ["",{"translate":"이 데이터팩은 총 16개의 팀을 추가합니다"}]
tellraw @s ["",{"translate":"팀 협동 모드와 팀 스코어보드가 제대로 작동하려면 다음 명령을 통해 플레이어를 팀에 추가해야 합니다"}]
tellraw @s ["",{"color":"gray","translate":"/team join bac_team_<color> <player>","click_event":{"action":"suggest_command","command":"/team join bac_team_"}}]
tellraw @s ["",{"translate":"이 명령을 통해 팀에 대한 설정을 자유롭게 변경할 수 있습니다"}]

# Go back
tellraw @s {"text":"                                             ","color":"dark_gray","strikethrough":true}
tellraw @s ["",{"text":"[ «« ]","color":"red","click_event":{"action":"run_command","command":"/function blazeandcave:config/help_menu"},"hover_event":{"action":"show_text","value":["",{"translate":"클릭하여 돌아가기","color":"gold"}]}}," ",{"translate":"돌아가기"}]

tellraw @s {"text":"                                             ","color":"dark_gray","strikethrough":true}
