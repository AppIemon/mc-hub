tellraw @s {"text":"                                             ","color":"dark_gray","strikethrough":true}
tellraw @s {"color":"gray","bold":false,"text":" ","extra":[{"color":"gray","bold":false,"translate":"새 데이터팩 버전으로 업데이트 하는 방법"}]}

tellraw @s {"text":"                                             ","color":"dark_gray","strikethrough":true}

# How
tellraw @s ["",{"translate":"1) 만약을 대비해 당신의 세계를 미리 백업하세요"}]
tellraw @s ["",{"translate":"2) 게임을 종료하고, 다음 과정 동안 당신의 세계에 들어가지 마세요"}]
tellraw @s ["",{"translate":"3) 이전 데이터팩을 당신의 세계에서 '완전히' 지우세요"}]
tellraw @s ["",{"translate":"4) 새로운 데이터팩을 당신의 세계에 추가하세요"}]
tellraw @s ["",{"translate":"5) 당신의 세계로 들어가세요. 새로 적용한 데이터팩과 마인크래프트의 버전이 맞는지 확인하세요"}]
tellraw @s ["",{"translate":"6) 오류가 났다면 백업 파일을 이용해 2-6 단계를 반복하세요"}]

# Go back
tellraw @s {"text":"                                             ","color":"dark_gray","strikethrough":true}
tellraw @s ["",{"text":"[ «« ]","color":"red","click_event":{"action":"run_command","command":"/function blazeandcave:config/help_menu"},"hover_event":{"action":"show_text","value":["",{"translate":"클릭하여 돌아가기","color":"gold"}]}}," ",{"translate":"돌아가기"}]

tellraw @s {"text":"                                             ","color":"dark_gray","strikethrough":true}
