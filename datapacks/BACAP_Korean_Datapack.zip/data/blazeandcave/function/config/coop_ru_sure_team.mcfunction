# Asks "Are you sure?"

tellraw @s {"text":"                                             ","color":"dark_gray","strikethrough":true}
tellraw @s [" ",{"color":"red","translate":"정말입니까?"}]
tellraw @s [" ",{"translate":"팀 협동 모드는 플레이어가 발전 과제를 해금할 때마다 팀의 모든 구성원들과 공유하도록 합니다"}]
tellraw @s [" ",{"color":"gold","translate":"이 기능을 설정하면 즉시 팀과 발전 과제를 공유하게 됩니다"}]
tellraw @s [" ",{"color":"red","translate":"모드를 비활성화해도 이미 공유된 발전 과제는 철회되지 않습니다"}]
tellraw @s {"text":"                                             ","color":"dark_gray","strikethrough":true}

tellraw @s ["",{"translate":"[ 예 ]","color":"green","click_event":{"action":"run_command","command":"/function blazeandcave:config/coop_on_team"},"hover_event":{"action":"show_text","value":["",{"translate":"클릭하여 확인","color":"gold"}]}}," ",{"translate":"[ 아니오 ]","color":"red","click_event":{"action":"run_command","command":"/function blazeandcave:config"},"hover_event":{"action":"show_text","value":["",{"translate":"클릭하여 돌아가기","color":"gold"}]}}]