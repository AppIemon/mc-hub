tellraw @s {"text":"                                             ","color":"dark_gray","strikethrough":true}
tellraw @s {"color":"gray","bold":false,"text":" ","extra":[{"color":"gray","bold":false,"translate":"관리자 설정"}]}

tellraw @s {"text":"                                             ","color":"dark_gray","strikethrough":true}

# Warning
tellraw @s {"bold":false,"text":" ","extra":[{"color":"red","bold":false,"translate":"경고: 몇몇 항목들은 게임 진행에 악영향을 미칠 수 있으며 버그를 발생시킬 수 있습니다. 조심해서 사용하세요!"}]}

tellraw @s {"text":"                                             ","color":"dark_gray","strikethrough":true}

# Global Install
tellraw @s ["",{"text":"[ »» ]","color":"light_purple","click_event":{"action":"run_command","command":"/function blazeandcave:global_install"},"hover_event":{"action":"show_text","value":["",{"translate":"datapacks 폴더에 설치된 하드코어, 테라리스, 기타 BACAP의 다른 버전의 데이터팩을 재정렬하고 올바르게 설치합니다.","color":"white"},{"text":"\n"},{"translate":"클릭하여 실행","color":"gold"}]}}," ",{"translate":"데이터팩 관리"}]
# Update Scoreboard
tellraw @s ["",{"text":"[ »» ]","color":"green","click_event":{"action":"run_command","command":"/function bacap_rewards:update_score"},"hover_event":{"action":"show_text","value":["",{"translate":"현재 접속 중인 플레이어들의 해금된 발전 과제를 다시 검사합니다","color":"white"},{"text":"\n"},{"translate":"이럴 때 사용하세요:","color":"white"},{"text":"\n"},{"translate":"- 데이터팩의 버전이 새롭게 업데이트 된 경우","color":"white"},{"text":"\n"},{"translate":"- 커맨드를 이용해 플레이어(들)의 발전 과제를 초기화한 경우","color":"white"},{"text":"\n"},{"translate":"클릭하여 실행","color":"gold"}]}}," ",{"translate":"스코어보드 갱신하기"}]
# Update Team Scoreboard
tellraw @s ["",{"text":"[ »» ]","color":"aqua","click_event":{"action":"run_command","command":"/function bacap_rewards:team_score"},"hover_event":{"action":"show_text","value":["",{"translate":"팀 스코어보드의 값을 다시 계산합니다","color":"white"},{"text":"\n"},{"translate":"클릭하여 실행","color":"gold"}]}}," ",{"translate":"팀 스코어보드 갱신하기"}]
# Resets Obtained Advancements
tellraw @s ["",{"text":"[ »» ]","color":"red","click_event":{"action":"run_command","command":"/execute as @a run function blazeandcave:config/reset_bac_obtained_ru_sure"},"hover_event":{"action":"show_text","value":["",{"translate":"'bac_obtained' 스코어보드를 초기화합니다. 그러면 협동 모드에서 더 이상 발전 과제가 공유되지 않으며 모든 발전 과제가 발전 과제 스코어보드에 맞춰 다시 설정됩니다","color":"white"},{"text":"\n"},{"translate":"클릭하여 실행","color":"gold"}]}}," ",{"translate":"bac_obtained 초기화"}]
# Refresh Cooperative Mode sharing (only shows up if Cooperative Mode is currently on)
execute if score coop bac_settings matches 1 run tellraw @s ["",{"text":"[ »» ]","color":"yellow","click_event":{"action":"run_command","command":"/function blazeandcave:config/coop_update"},"hover_event":{"action":"show_text","value":["",{"translate":"클릭하여 실행","color":"gold"}]}}," ",{"translate":"협동 모드의 발전 과제 공유를 새로고침"}]
execute if score coop bac_settings matches 2 run tellraw @s ["",{"text":"[ »» ]","color":"yellow","click_event":{"action":"run_command","command":"/execute as @a run function blazeandcave:config/coop_update_team"},"hover_event":{"action":"show_text","value":["",{"translate":"클릭하여 실행","color":"gold"}]}}," ",{"translate":"협동 모드의 발전 과제 공유를 새로고침"}]
# Trophy granting
tellraw @s ["",{"text":"[ »» ]","color":"gold","click_event":{"action":"run_command","command":"/function blazeandcave:config/trophies_ru_sure"},"hover_event":{"action":"show_text","value":["",{"translate":"현재 접속 중인 플레이어들에게 지금까지 획득한 트로피를 다시 지급합니다","color":"white"},{"text":"\n"},{"translate":"이 기능은 트로피 업데이트(BACAP 1.11) 이전에 생성된 월드에서 사용해야 합니다","color":"white"},{"text":"\n"},{"translate":"클릭하여 실행","color":"gold"}]}}," ",{"translate":"트로피 재지급"}]
# Revoke Death Advancements
tellraw @s ["",{"text":"[ »» ]","color":"#FF2A2A","click_event":{"action":"run_command","command":"/function blazeandcave:config/hardcore_to_survival"},"hover_event":{"action":"show_text","value":["",{"translate":"죽어야 달성되는 발전 과제를 해제합니다. 이 기능은 하드코어 모드에서 하드코어 버전의 데이터팩을 플레이하다 죽었지만, 일반 버전으로 이어서 플레이하고 싶을 때 사용해야 합니다.","color":"white"},{"text":"\n"},{"translate":"클릭하여 실행","color":"gold"}]}}," ",{"translate":"죽음 관련 발전 과제 해제(일반 버전으로 전환)"}]
# Revoke all advancements
tellraw @s ["",{"text":"[ »» ]","color":"dark_red","click_event":{"action":"run_command","command":"/function blazeandcave:config/revoke_ru_sure"},"hover_event":{"action":"show_text","value":["",{"translate":"모든 발전 과제를 철회하고, 스코어보드를 초기화합니다","color":"white"},{"text":"\n"},{"translate":"자신 또는 자신과 가장 가까운 플레이어 또는 모든 플레이어를 대상으로 합니다","color":"white"},{"text":"\n"},{"translate":"클릭하여 실행","color":"gold"}]}}," ",{"translate":"발전 과제 철회"}]

tellraw @s {"text":"                                             ","color":"dark_gray","strikethrough":true}

# Go back
tellraw @s ["",{"text":"[ «« ]","color":"red","click_event":{"action":"run_command","command":"/function blazeandcave:config"},"hover_event":{"action":"show_text","value":["",{"translate":"클릭하여 돌아가기","color":"gold"}]}}," ",{"translate":"메인 메뉴로 돌아가기"}]

tellraw @s {"text":"                                             ","color":"dark_gray","strikethrough":true}
