tellraw @s {"text":"                                             ","color":"dark_gray","strikethrough":true}
tellraw @s {"color":"gray","bold":false,"text":" ","extra":[{"color":"gray","bold":false,"translate":"오류가 생겼을 때"}]}

tellraw @s {"text":"                                             ","color":"dark_gray","strikethrough":true}

# How
tellraw @s ["",{"translate":"데이터팩의 한 부분이 제대로 작동하지 않는 경우(달성되지 않아야 할 발전 과제가 달성될 때), 실행 중인 마인크래프트의 버전이 데이터팩의 버전과 맞는지 확인해보세요"}]
tellraw @s ["",{"translate":"또한 Spigot 또는 Paper 서버에서는 몇몇 발전 과제가 달성되지 않을 수도 있습니다"}]

# Go back
tellraw @s {"text":"                                             ","color":"dark_gray","strikethrough":true}
tellraw @s ["",{"text":"[ «« ]","color":"red","click_event":{"action":"run_command","command":"/function blazeandcave:config/help_menu"},"hover_event":{"action":"show_text","value":["",{"translate":"클릭하여 돌아가기","color":"gold"}]}}," ",{"translate":"돌아가기"}]

tellraw @s {"text":"                                             ","color":"dark_gray","strikethrough":true}
