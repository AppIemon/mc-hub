execute if entity @p[distance=0.001..] run tellraw @s {"text":"","extra":[{"color":"yellow","translate":"%1$s에 의해 모든 발전 과제가 철회되었습니다","with":[{"selector":"@p[distance=0.001..]"}]}]}
execute unless entity @p[distance=0.001..] run tellraw @s {"text":"","extra":[{"color":"red","translate":"에러: 현재 접속 중인 플레이어가 없습니다"}]}

execute as @p[distance=0.001..] run function blazeandcave:config/revoke_begin

function blazeandcave:config/technical_settings