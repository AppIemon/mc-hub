# Asks "Are you sure?"

tellraw @s {"text":"                                             ","color":"dark_gray","strikethrough":true}
tellraw @s [" ",{"color":"red","translate":"정말입니까?"}]
tellraw @s [" ",{"translate":"협동 모드는 발전 과제가 모두와 공유되는 모드입니다."}]
tellraw @s [" ",{"color":"gold","translate":"이 모드를 사용하면 모든 플레이어끼리 발전 과제가 공유됩니다"}]
tellraw @s [" ",{"color":"red","translate":"모드를 비활성화해도 이미 공유된 발전 과제는 철회되지 않습니다"}]
tellraw @s {"text":"                                             ","color":"dark_gray","strikethrough":true}

tellraw @s ["",{"translate":"[ 예 ]","color":"green","click_event":{"action":"run_command","command":"/function blazeandcave:config/coop_on"},"hover_event":{"action":"show_text","value":["",{"translate":"클릭하여 확인","color":"gold"}]}}," ",{"translate":"[ 아니오 ]","color":"red","click_event":{"action":"run_command","command":"/function blazeandcave:config"},"hover_event":{"action":"show_text","value":["",{"translate":"클릭하여 돌아가기","color":"gold"}]}}]