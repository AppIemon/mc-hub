tellraw @s {"text":"                                             ","color":"dark_gray","strikethrough":true}
tellraw @s {"color":"gray","bold":false,"text":" ","extra":[{"color":"gray","bold":false,"translate":"언어 팩은 어떻게 적용하나요?"}]}

tellraw @s {"text":"                                             ","color":"dark_gray","strikethrough":true}

# How
tellraw @s ["",{"translate":"언어 팩은 데이터팩이 아닙니다"}]
tellraw @s ["",{"translate":"다른 리소스팩을 적용하는 방법처럼 적용하세요"}]
tellraw @s ["",{"translate":"resourcepacks 폴더에 언어 팩 파일을 넣고 리소스팩 메뉴에서 적용하세요"}]
tellraw @s ["",{"translate":"적용하게 되면, 언어 팩이 당신이 사용하는 언어를 지원하는 경우 그 언어로 발전 과제가 번역됩니다"}]

# Go back
tellraw @s {"text":"                                             ","color":"dark_gray","strikethrough":true}
tellraw @s ["",{"text":"[ «« ]","color":"red","click_event":{"action":"run_command","command":"/function blazeandcave:config/help_faq"},"hover_event":{"action":"show_text","value":["",{"translate":"클릭하여 돌아가기","color":"gold"}]}}," ",{"translate":"돌아가기"}]

tellraw @s {"text":"                                             ","color":"dark_gray","strikethrough":true}
