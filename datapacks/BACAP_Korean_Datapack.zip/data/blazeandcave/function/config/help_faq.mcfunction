tellraw @s {"text":"                                             ","color":"dark_gray","strikethrough":true}
tellraw @s {"color":"gray","bold":false,"text":" ","extra":[{"color":"gray","bold":false,"translate":"자주 묻는 질문"}]}

tellraw @s {"text":"                                             ","color":"dark_gray","strikethrough":true}

# Why aren't all tabs visible at the start?
tellraw @s ["",{"text":"[ »» ]","color":"yellow","click_event":{"action":"run_command","command":"/function blazeandcave:config/help_faq_not_all_tabs_visible"},"hover_event":{"action":"show_text","value":["",{"translate":"클릭하여 보기","color":"gold"}]}}," ",{"translate":"왜 모든 탭이 보이지 않나요?"}]

# How do I install the Language Pack?
tellraw @s ["",{"text":"[ »» ]","color":"aqua","click_event":{"action":"run_command","command":"/function blazeandcave:config/help_faq_language_install"},"hover_event":{"action":"show_text","value":["",{"translate":"클릭하여 보기","color":"gold"}]}}," ",{"translate":"언어 팩은 어떻게 적용하나요?"}]

# How can I translate the advancements into a new language?
tellraw @s ["",{"text":"[ »» ]","color":"dark_aqua","click_event":{"action":"run_command","command":"/function blazeandcave:config/help_faq_language_translate"},"hover_event":{"action":"show_text","value":["",{"translate":"클릭하여 보기","color":"gold"}]}}," ",{"translate":"번역을 하고 싶은데 어떻게 해야 하나요?"}]

# What is the name of the mod that lets you see progress on advancements? (Advancement Info)
tellraw @s ["",{"text":"[ »» ]","color":"gold","click_event":{"action":"run_command","command":"/function blazeandcave:config/help_faq_advinfo"},"hover_event":{"action":"show_text","value":["",{"translate":"클릭하여 보기","color":"gold"}]}}," ",{"translate":"발전 과제 진행 상황을 볼 수 있는 모드의 이름은 무엇인가요?"}]


# Go back
tellraw @s {"text":"                                             ","color":"dark_gray","strikethrough":true}
tellraw @s ["",{"text":"[ «« ]","color":"red","click_event":{"action":"run_command","command":"/function blazeandcave:config/help_menu"},"hover_event":{"action":"show_text","value":["",{"translate":"클릭하여 돌아가기","color":"gold"}]}}," ",{"translate":"메인 메뉴로 돌아가기"}]

tellraw @s {"text":"                                             ","color":"dark_gray","strikethrough":true}
