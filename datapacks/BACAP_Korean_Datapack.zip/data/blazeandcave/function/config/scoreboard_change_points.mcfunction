tellraw @s {"text":"                                             ","color":"dark_gray","strikethrough":true}
tellraw @s {"color":"gray","bold":false,"text":" ","extra":[{"color":"yellow","bold":false,"translate":"각 등급에 몇 점을 설정하시겠습니까?"}]}

tellraw @s {"text":"                                             ","color":"dark_gray","strikethrough":true}

# Scoreboards
tellraw @s ["",{"text":"[ »» ]","color":"green","click_event":{"action":"run_command","command":"/dialog show @s blazeandcave:config/change_points_task"},"hover_event":{"action":"show_text","value":["",{"translate":"클릭하여 변경하기","color":"gold"}]}}," ",{"color":"green","translate":"일반"}," ",{"translate":"발전 과제:"}," ",{"text":"           ","color":"white","strikethrough":true}," ",{"color":"yellow","bold":true,"score":{"name":"task","objective":"bac_points"}}]
tellraw @s ["",{"text":"[ »» ]","color":"#75E1FF","click_event":{"action":"run_command","command":"/dialog show @s blazeandcave:config/change_points_goal"},"hover_event":{"action":"show_text","value":["",{"translate":"클릭하여 변경하기","color":"gold"}]}}," ",{"color":"#75E1FF","translate":"목표"}," ",{"translate":"발전 과제:"}," ",{"text":"           ","color":"white","strikethrough":true}," ",{"color":"yellow","bold":true,"score":{"name":"goal","objective":"bac_points"}}]
tellraw @s ["",{"text":"[ »» ]","color":"dark_purple","click_event":{"action":"run_command","command":"/dialog show @s blazeandcave:config/change_points_challenge"},"hover_event":{"action":"show_text","value":["",{"translate":"클릭하여 변경하기","color":"gold"}]}}," ",{"color":"dark_purple","translate":"도전"}," ",{"translate":"발전 과제:"}," ",{"text":"    ","color":"white","strikethrough":true}," ",{"color":"yellow","bold":true,"score":{"name":"challenge","objective":"bac_points"}}]
tellraw @s ["",{"text":"[ »» ]","color":"#FF2A2A","click_event":{"action":"run_command","command":"/dialog show @s blazeandcave:config/change_points_super_challenge"},"hover_event":{"action":"show_text","value":["",{"translate":"클릭하여 변경하기","color":"gold"}]}}," ",{"color":"#FF2A2A","translate":"극한 과제"},": ",{"text":"            ","color":"white","strikethrough":true}," ",{"color":"yellow","bold":true,"score":{"name":"super_challenge","objective":"bac_points"}}]
tellraw @s ["",{"text":"[ »» ]","color":"yellow","click_event":{"action":"run_command","command":"/dialog show @s blazeandcave:config/change_points_milestone"},"hover_event":{"action":"show_text","value":["",{"translate":"클릭하여 변경하기","color":"gold"}]}}," ",{"color":"yellow","translate":"올클리어"}," ",{"translate":"발전 과제:"}," ",{"text":"     ","color":"white","strikethrough":true}," ",{"color":"yellow","bold":true,"score":{"name":"milestone","objective":"bac_points"}}]
tellraw @s ["",{"text":"[ »» ]","color":"light_purple","click_event":{"action":"run_command","command":"/dialog show @s blazeandcave:config/change_points_hidden"},"hover_event":{"action":"show_text","value":["",{"translate":"클릭하여 변경하기","color":"gold"}]}}," ",{"color":"light_purple","translate":"숨김"}," ",{"translate":"발전 과제:"}," ",{"text":"        ","color":"white","strikethrough":true}," ",{"color":"yellow","bold":true,"score":{"name":"hidden","objective":"bac_points"}}]
tellraw @s ["",{"text":"[ »» ]","color":"gold","click_event":{"action":"run_command","command":"/dialog show @s blazeandcave:config/change_points_advancement_legend"},"hover_event":{"action":"show_text","value":["",{"translate":"클릭하여 변경하기","color":"gold"}]}}," ",{"color":"gold","translate":"발전 과제의 전설"},": ",{"text":"        ","color":"white","strikethrough":true}," ",{"color":"yellow","bold":true,"score":{"name":"advancement_legend","objective":"bac_points"}}]

tellraw @s {"text":"                                             ","color":"dark_gray","strikethrough":true}

tellraw @s ["",{"text":"[ »» ]","color":"red","click_event":{"action":"run_command","command":"/function blazeandcave:config/scoreboard_change_points_reset"},"hover_event":{"action":"show_text","value":["",{"translate":"클릭하여 초기화하기","color":"gold"}]}}," ",{"translate":"기본값으로 초기화"}]

tellraw @s {"text":"                                             ","color":"dark_gray","strikethrough":true}

# Go back
tellraw @s ["",{"text":"[ «« ]","color":"red","click_event":{"action":"run_command","command":"/function blazeandcave:config/scoreboard_settings"},"hover_event":{"action":"show_text","value":["",{"translate":"클릭하여 돌아가기","color":"gold"}]}}," ",{"translate":"돌아가기"}]

tellraw @s {"text":"                                             ","color":"dark_gray","strikethrough":true}
