# Asks "Are you sure?"

tellraw @s {"text":"                                             ","color":"dark_gray","strikethrough":true}
tellraw @s [" ",{"color":"yellow","translate":"정말입니까?"}]
tellraw @s {"text":"                                             ","color":"dark_gray","strikethrough":true}
tellraw @s [" ",{"color":"red","translate":"이 기능은 발전 과제가 다시 해금될 때까지 협동 모드의 발전 과제 공유를 중지하고, 발전 과제 스코어보드에 대해 발전 과제를 다시 설정합니다"}]
tellraw @s [" ",{"translate":"협동 모드를 해제하려는 경우에 사용하세요"}]
tellraw @s {"text":"                                             ","color":"dark_gray","strikethrough":true}

tellraw @s ["",{"translate":"[ 예 ]","color":"green","click_event":{"action":"run_command","command":"/function blazeandcave:config/reset_bac_obtained"},"hover_event":{"action":"show_text","value":["",{"translate":"클릭하여 확인","color":"gold"}]}}," ",{"translate":"[ 아니오 ]","color":"red","click_event":{"action":"run_command","command":"/function blazeandcave:config/technical_settings"},"hover_event":{"action":"show_text","value":["",{"translate":"클릭하여 돌아가기","color":"gold"}]}}]