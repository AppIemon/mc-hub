tellraw @s {"text":"                                             ","color":"dark_gray","strikethrough":true}
tellraw @s {"color":"gray","bold":false,"text":" ","extra":[{"color":"gray","bold":false,"translate":"발전 과제 진행 상황을 볼 수 있는 모드의 이름은 무엇인가요?"}]}

tellraw @s {"text":"                                             ","color":"dark_gray","strikethrough":true}

# How
tellraw @s ["",{"translate":"자주 질문하시는 Advancement Info Reloaded 모드를 설치하시면 발전 과제의 진척 현황을 알 수 있습니다."}]
tellraw @s ["",{"translate":"이 모드는 '블록 정복자'같이 달성 조건이 많은 극한 과제에 유용합니다"}]
tellraw @s ["",{"translate":"모드 다운로드"}]
tellraw @s ["",{"color":"aqua","underlined": true,"text":"https://modrinth.com/mod/advancements-reloaded","click_event":{"action":"open_url","url":"https://modrinth.com/mod/advancements-reloaded"},"hover_event":{"action":"show_text","value":["",{"translate":"클릭하여 링크 열기","color":"gold"}]}}]

# Go back
tellraw @s {"text":"                                             ","color":"dark_gray","strikethrough":true}
tellraw @s ["",{"text":"[ «« ]","color":"red","click_event":{"action":"run_command","command":"/function blazeandcave:config/help_faq"},"hover_event":{"action":"show_text","value":["",{"translate":"클릭하여 돌아가기","color":"gold"}]}}," ",{"translate":"돌아가기"}]

tellraw @s {"text":"                                             ","color":"dark_gray","strikethrough":true}
