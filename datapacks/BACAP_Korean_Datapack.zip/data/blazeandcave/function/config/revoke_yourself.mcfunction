tellraw @s {"text":"","extra":[{"color":"yellow","translate":"%1$s에 의해 모든 발전 과제가 철회되었습니다","with":[{"selector":"@s"}]}]}

execute as @s run function blazeandcave:config/revoke_begin

function blazeandcave:config/technical_settings