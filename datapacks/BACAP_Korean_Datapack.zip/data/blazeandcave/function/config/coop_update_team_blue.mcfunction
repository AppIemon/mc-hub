# Function that updates everyone's shared advancements based on what everyone currently has

function #bacap_fanpacks:config/coop_update_team_blue

# Go through every advancement, and adds 1 to score if you have obtained that advancement
execute if score blazeandcave:adventure/businessman bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/businessman
execute if score blazeandcave:adventure/disc_jockey bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/disc_jockey
execute if score blazeandcave:adventure/do_you_want_to_trade bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/do_you_want_to_trade
execute if score blazeandcave:adventure/dry_spell bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/dry_spell
execute if score blazeandcave:adventure/filthy_rich bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/filthy_rich
execute if score blazeandcave:adventure/filthy_stinkin_rich bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/filthy_stinkin_rich
execute if score blazeandcave:adventure/ghostbuster bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/ghostbuster
execute if score blazeandcave:adventure/grave_robber bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/grave_robber
execute if score blazeandcave:adventure/guardian_destroyer bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/guardian_destroyer
execute if score blazeandcave:adventure/heres_johnny bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/heres_johnny
execute if score blazeandcave:adventure/house_of_psychos bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/house_of_psychos
execute if score blazeandcave:adventure/i_hereby_dub_thee bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/i_hereby_dub_thee
execute if score blazeandcave:adventure/if_only_cats_grew_into_kittens bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/if_only_cats_grew_into_kittens
execute if score blazeandcave:adventure/laser_sharks bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/laser_sharks
execute if score blazeandcave:adventure/knowledge_is_power bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/knowledge_is_power
execute if score blazeandcave:adventure/mapmaker bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/mapmaker
execute if score blazeandcave:adventure/monumental bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/monumental
execute if score blazeandcave:adventure/murderer bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/murderer
execute if score blazeandcave:adventure/music_to_my_ears bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/music_to_my_ears
execute if score blazeandcave:adventure/overpowered bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/overpowered
execute if score blazeandcave:adventure/raidin_master bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/raidin_master
execute if score blazeandcave:adventure/rekt bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/rekt
execute if score blazeandcave:adventure/secret_of_the_igloo bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/secret_of_the_igloo
execute if score blazeandcave:adventure/seafood_skewer bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/seafood_skewer
execute if score blazeandcave:adventure/sponge_miner bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/sponge_miner
execute if score blazeandcave:adventure/the_deep_end bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/the_deep_end
execute if score blazeandcave:adventure/the_shielding bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/the_shielding
execute if score blazeandcave:adventure/tomb_raider bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/tomb_raider
execute if score blazeandcave:adventure/travelling_merchant bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/travelling_merchant
execute if score blazeandcave:adventure/treasure_map bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/treasure_map
execute if score blazeandcave:adventure/witchcraft bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/witchcraft
execute if score blazeandcave:adventure/wololo bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/wololo


execute if score blazeandcave:animal/a_horse_in_shining_armor bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/a_horse_in_shining_armor
execute if score blazeandcave:animal/aquarium bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/aquarium
execute if score blazeandcave:animal/are_we_there_yet bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/are_we_there_yet
execute if score blazeandcave:animal/artificial_selection bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/artificial_selection
execute if score blazeandcave:animal/bacon bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/bacon
execute if score blazeandcave:animal/blistering_barnacles bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/blistering_barnacles
execute if score blazeandcave:animal/catching_nemo bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/catching_nemo
execute if score blazeandcave:biomes/chatterbox bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:biomes/chatterbox
execute if score blazeandcave:animal/chicken_cooper bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/chicken_cooper
execute if score blazeandcave:animal/cow_tipper bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/cow_tipper
execute if score blazeandcave:animal/cowboy bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/cowboy
execute if score blazeandcave:animal/direct_fishing bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/direct_fishing
execute if score blazeandcave:animal/foal_play bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/foal_play
execute if score blazeandcave:animal/feeding_the_chickens bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/feeding_the_chickens
execute if score blazeandcave:animal/feeling_sheepish bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/feeling_sheepish
execute if score blazeandcave:animal/fuzzy_feet bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/fuzzy_feet
execute if score blazeandcave:animal/getting_into_a_stew bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/getting_into_a_stew
execute if score blazeandcave:animal/grinding_nemo bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/grinding_nemo
execute if score blazeandcave:animal/have_a_shearful_day bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/have_a_shearful_day
execute if score blazeandcave:animal/hey_look_mom bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/hey_look_mom
execute if score blazeandcave:animal/high_steaks bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/high_steaks
execute if score blazeandcave:animal/in_a_hole_there_lived_a_rabbit bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/in_a_hole_there_lived_a_rabbit
execute if score blazeandcave:animal/lucky_charm bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/lucky_charm
execute if score blazeandcave:animal/mary_had_a_little_lamb bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/mary_had_a_little_lamb
execute if score blazeandcave:animal/master_angler bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/master_angler
execute if score blazeandcave:animal/milk_does_your_body_good bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/milk_does_your_body_good
execute if score blazeandcave:animal/mooshroom_kingdom bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/mooshroom_kingdom
execute if score blazeandcave:animal/pig_slaughterer bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/pig_slaughterer
execute if score blazeandcave:animal/poacher bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/poacher
execute if score blazeandcave:animal/pork_chop bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/pork_chop
execute if score blazeandcave:animal/puppies_yipe bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/puppies_yipe
execute if score blazeandcave:animal/rabbit_season bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/rabbit_season
execute if score blazeandcave:animal/rainbow_collection bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/rainbow_collection
execute if score blazeandcave:animal/salmonella_poisoning bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/salmonella_poisoning
execute if score blazeandcave:animal/scuttler bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/scuttler
execute if score blazeandcave:animal/sheariously bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/sheariously
execute if score blazeandcave:animal/so_good bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/so_good
execute if score blazeandcave:animal/so_i_got_that_going_for_me bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/so_i_got_that_going_for_me
execute if score blazeandcave:animal/someones_been_here_before bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/someones_been_here_before
execute if score blazeandcave:animal/stay_calmer bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/stay_calmer
execute if score blazeandcave:animal/super_mooshroom bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/super_mooshroom
execute if score blazeandcave:animal/sushi bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/sushi
execute if score blazeandcave:animal/theyre_breeding_like_rabbits bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/theyre_breeding_like_rabbits
execute if score blazeandcave:animal/tickle_time bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/tickle_time
execute if score blazeandcave:animal/totally_not_an_afk_fisher bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/totally_not_an_afk_fisher
execute if score blazeandcave:animal/treasure_hunter bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/treasure_hunter
execute if score blazeandcave:farming/trimming_the_treetops bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:farming/trimming_the_treetops
execute if score blazeandcave:animal/tropical_collection bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/tropical_collection
execute if score blazeandcave:animal/true_cow_tipper bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/true_cow_tipper
execute if score blazeandcave:animal/turtle_army bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/turtle_army
execute if score blazeandcave:animal/turtle_soldier bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/turtle_soldier
execute if score blazeandcave:animal/what_a_piece_of_junk bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/what_a_piece_of_junk
execute if score blazeandcave:animal/when_pigs_used_to_fly bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/when_pigs_used_to_fly
execute if score blazeandcave:animal/wooly bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/wooly
execute if score blazeandcave:farming/yay_deadbush bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:farming/yay_deadbush
execute if score blazeandcave:animal/you_lead_ill_follow bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/you_lead_ill_follow


execute if score blazeandcave:bacap/getting_wood bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:bacap/getting_wood
execute if score blazeandcave:bacap/root bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:bacap/root
execute if score blazeandcave:bacap/time_to_chop bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:bacap/time_to_chop
execute if score blazeandcave:bacap/time_to_farm bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:bacap/time_to_farm
execute if score blazeandcave:bacap/time_to_mine bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:bacap/time_to_mine
execute if score blazeandcave:bacap/time_to_strike bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:bacap/time_to_strike


execute if score blazeandcave:biomes/atlantis bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:biomes/atlantis
execute if score blazeandcave:biomes/boaty_mcboatface bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:biomes/boaty_mcboatface
execute if score blazeandcave:biomes/high_feet bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:biomes/high_feet
execute if score blazeandcave:biomes/dolphin_dasher bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:biomes/dolphin_dasher
execute if score blazeandcave:biomes/enchanted_forest bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:biomes/enchanted_forest
execute if score blazeandcave:challenges/explorer_of_worlds bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:challenges/explorer_of_worlds
execute if score blazeandcave:biomes/flower_power bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:biomes/flower_power
execute if score blazeandcave:biomes/ahoy bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:biomes/ahoy
execute if score blazeandcave:biomes/in_a_pickle bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:biomes/in_a_pickle
execute if score blazeandcave:biomes/just_a_sample bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:biomes/just_a_sample
execute if score blazeandcave:biomes/just_keep_swimming bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:biomes/just_keep_swimming
execute if score blazeandcave:biomes/kilometre_walk bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:biomes/kilometre_walk
execute if score blazeandcave:biomes/no_reefing bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:biomes/no_reefing
execute if score blazeandcave:biomes/one_with_the_forest bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:biomes/one_with_the_forest
execute if score blazeandcave:biomes/overgrown bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:biomes/overgrown
execute if score blazeandcave:biomes/moskstraumen bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:biomes/moskstraumen
execute if score blazeandcave:biomes/pushed_around bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:biomes/pushed_around
execute if score blazeandcave:biomes/root bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:biomes/root
execute if score blazeandcave:biomes/cold_feet bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:biomes/cold_feet
execute if score blazeandcave:biomes/spike_ice bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:biomes/spike_ice
execute if score blazeandcave:biomes/tarzan bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:biomes/tarzan
execute if score blazeandcave:biomes/ten_thousand_blocks bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:biomes/ten_thousand_blocks
execute if score blazeandcave:biomes/the_great_blocky_reef bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:biomes/the_great_blocky_reef
execute if score blazeandcave:biomes/the_sea_calls_you bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:biomes/the_sea_calls_you
execute if score blazeandcave:biomes/theres_a_zombie_on_the_lawn bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:biomes/theres_a_zombie_on_the_lawn
execute if score blazeandcave:biomes/thick_ice bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:biomes/thick_ice
execute if score blazeandcave:biomes/thin_ice bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:biomes/thin_ice
execute if score blazeandcave:biomes/titanic bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:biomes/titanic
execute if score blazeandcave:biomes/voyage bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:biomes/voyage
execute if score blazeandcave:biomes/warm_feet bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:biomes/warm_feet
execute if score blazeandcave:biomes/wet_feet bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:biomes/wet_feet
execute if score blazeandcave:biomes/x_marks_the_spot bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:biomes/x_marks_the_spot


execute if score blazeandcave:building/a_masterpiece bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:building/a_masterpiece
execute if score blazeandcave:building/ah_my_old_enemy bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:building/ah_my_old_enemy
execute if score blazeandcave:building/barking_mad bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:building/barking_mad
execute if score blazeandcave:building/bricks bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:building/bricks
execute if score blazeandcave:building/change_of_sheets bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:building/change_of_sheets
execute if score blazeandcave:building/classy_glassy bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:building/classy_glassy
execute if score blazeandcave:building/clay_dough bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:building/clay_dough
execute if score blazeandcave:building/concrete_evidence bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:building/concrete_evidence
execute if score blazeandcave:building/creepers_and_withers bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:building/creepers_and_withers
execute if score blazeandcave:building/help_ive_been_framed bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:building/help_ive_been_framed
execute if score blazeandcave:building/electric bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:building/electric
execute if score blazeandcave:building/en_garde bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:building/en_garde
execute if score blazeandcave:building/expensive bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:building/expensive
execute if score blazeandcave:building/fake_fortress bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:building/fake_fortress
execute if score blazeandcave:building/fake_monument bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:building/fake_monument
execute if score blazeandcave:building/fake_stronghold bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:building/fake_stronghold
execute if score blazeandcave:building/fluorescent bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:building/fluorescent
execute if score blazeandcave:building/glowing bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:building/glowing
execute if score blazeandcave:building/greek_art_decor bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:building/greek_art_decor
execute if score blazeandcave:building/halloween bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:building/halloween
execute if score blazeandcave:building/its_a_sign bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:building/its_a_sign
execute if score blazeandcave:building/its_a_trap bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:building/its_a_trap
execute if score blazeandcave:building/jailhouse_block bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:building/jailhouse_block
execute if score blazeandcave:building/ladder_climbers_inc bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:building/ladder_climbers_inc
execute if score blazeandcave:building/lost_its_bark bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:building/lost_its_bark
execute if score blazeandcave:building/mannequin bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:building/mannequin
execute if score blazeandcave:building/master_logger bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:building/master_logger
execute if score blazeandcave:building/no_banner_only_color bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:building/no_banner_only_color
execute if score blazeandcave:building/pathways bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:building/pathways
execute if score blazeandcave:building/pot_planter bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:building/pot_planter
execute if score blazeandcave:building/professor_birch bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:building/professor_birch
execute if score blazeandcave:building/professor_dark_oak bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:building/professor_dark_oak
execute if score blazeandcave:building/professor_oak bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:building/professor_oak
execute if score blazeandcave:building/rainbow_dreams bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:building/rainbow_dreams
execute if score blazeandcave:building/rainbow_sand bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:building/rainbow_sand
execute if score blazeandcave:building/raise_the_flag bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:building/raise_the_flag
execute if score blazeandcave:building/rock_collection bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:building/rock_collection
execute if score blazeandcave:building/root bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:building/root
execute if score blazeandcave:building/slabs_for_days bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:building/slabs_for_days
execute if score blazeandcave:building/spruce_lee bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:building/spruce_lee
execute if score blazeandcave:building/stationary_storage bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:building/stationary_storage
execute if score blazeandcave:building/stripper bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:building/stripper
execute if score blazeandcave:building/the_acacia_king bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:building/the_acacia_king
execute if score blazeandcave:building/the_glazed_terracotta_army bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:building/the_glazed_terracotta_army
execute if score blazeandcave:building/the_jungler bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:building/the_jungler
execute if score blazeandcave:building/the_rainbow_you_always_wanted bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:building/the_rainbow_you_always_wanted
execute if score blazeandcave:building/the_terracotta_army bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:building/the_terracotta_army
execute if score blazeandcave:building/the_walls bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:building/the_walls
execute if score blazeandcave:building/torched bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:building/torched
execute if score blazeandcave:building/translucence bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:building/translucence
execute if score blazeandcave:building/what_a_pane bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:building/what_a_pane
execute if score blazeandcave:building/yay_i_got_my_wood bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:building/yay_i_got_my_wood
execute if score blazeandcave:building/your_door_was_locked bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:building/your_door_was_locked


execute if score blazeandcave:monsters/a_watery_grave bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:monsters/a_watery_grave
execute if score blazeandcave:monsters/anti_air bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:monsters/anti_air
execute if score blazeandcave:monsters/because_im_aquaman bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:monsters/because_im_aquaman
execute if score blazeandcave:monsters/blast_shield bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:monsters/blast_shield
execute if score blazeandcave:monsters/boned bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:monsters/boned
execute if score blazeandcave:monsters/camouflage bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:monsters/camouflage
execute if score blazeandcave:monsters/creeper_killer bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:monsters/creeper_killer
execute if score blazeandcave:monsters/creepy_heads bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:monsters/creepy_heads
execute if score blazeandcave:monsters/dead_dont_die bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:monsters/dead_dont_die
execute if score blazeandcave:monsters/desert_nomad bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:monsters/desert_nomad
execute if score blazeandcave:monsters/dungeon_crawler bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:monsters/dungeon_crawler
execute if score blazeandcave:monsters/ender_worm bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:monsters/ender_worm
execute if score blazeandcave:monsters/enderman_destroyer bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:monsters/enderman_destroyer
execute if score blazeandcave:biomes/barbearian bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:biomes/barbearian
execute if score blazeandcave:monsters/ew_ew_ew bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:monsters/ew_ew_ew
execute if score blazeandcave:monsters/freezing bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:monsters/freezing
execute if score blazeandcave:monsters/frosty bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:monsters/frosty
execute if score blazeandcave:monsters/gelatinous_cube bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:monsters/gelatinous_cube
execute if score blazeandcave:monsters/hell_hunter bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:monsters/hell_hunter
execute if score blazeandcave:monsters/iron_belly bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:monsters/iron_belly
execute if score blazeandcave:monsters/keep_your_distance bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:monsters/keep_your_distance
execute if score blazeandcave:monsters/melting bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:monsters/melting
execute if score blazeandcave:monsters/night_runner bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:monsters/night_runner
execute if score blazeandcave:monsters/phantom_slayer bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:monsters/phantom_slayer
execute if score blazeandcave:monsters/plane_walker bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:monsters/plane_walker
execute if score blazeandcave:monsters/poisonous_ew bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:monsters/poisonous_ew
execute if score blazeandcave:monsters/ricochet_swoop bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:monsters/ricochet_swoop
execute if score blazeandcave:monsters/root bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:monsters/root
execute if score blazeandcave:monsters/skeleton_smiter bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:monsters/skeleton_smiter
execute if score blazeandcave:monsters/slime_squisher bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:monsters/slime_squisher
execute if score blazeandcave:monsters/spider_smasher bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:monsters/spider_smasher
execute if score blazeandcave:monsters/spooky_skeleton bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:monsters/spooky_skeleton
execute if score blazeandcave:monsters/spooky_skulls bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:monsters/spooky_skulls
execute if score blazeandcave:monsters/still_talking bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:monsters/still_talking
execute if score blazeandcave:monsters/taste_of_your_own_medicine bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:monsters/taste_of_your_own_medicine
execute if score blazeandcave:monsters/tele_morph bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:monsters/tele_morph
execute if score blazeandcave:monsters/termite_control bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:monsters/termite_control
execute if score blazeandcave:monsters/the_ender_of_ender bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:monsters/the_ender_of_ender
execute if score blazeandcave:monsters/the_ghastly_eyes bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:monsters/the_ghastly_eyes
execute if score blazeandcave:monsters/the_phantom_menace bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:monsters/the_phantom_menace
execute if score blazeandcave:monsters/the_undead_cavalry bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:monsters/the_undead_cavalry
execute if score blazeandcave:monsters/there_has_to_be_another_way bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:monsters/there_has_to_be_another_way
execute if score blazeandcave:monsters/trampoline bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:monsters/trampoline
execute if score blazeandcave:monsters/tridented_shield bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:monsters/tridented_shield
execute if score blazeandcave:monsters/void_ender bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:monsters/void_ender
execute if score blazeandcave:monsters/well_handle_this bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:monsters/well_handle_this
execute if score blazeandcave:monsters/what_a_creep bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:monsters/what_a_creep
execute if score blazeandcave:monsters/witch bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:monsters/witch
execute if score blazeandcave:monsters/zombie_slayer bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:monsters/zombie_slayer


execute if score blazeandcave:enchanting/armor_for_the_masses bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:enchanting/armor_for_the_masses
execute if score blazeandcave:enchanting/bane_of_one_shotting_spiders bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:enchanting/bane_of_one_shotting_spiders
execute if score blazeandcave:enchanting/boomerang bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:enchanting/boomerang
execute if score blazeandcave:enchanting/bow_down_to_me bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:enchanting/bow_down_to_me
execute if score blazeandcave:enchanting/complete_enchanter bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:enchanting/complete_enchanter
execute if score blazeandcave:enchanting/curses bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:enchanting/curses
execute if score blazeandcave:enchanting/do_a_barrel_roll bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:enchanting/do_a_barrel_roll
execute if score blazeandcave:enchanting/fiery bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:enchanting/fiery
execute if score blazeandcave:enchanting/fortunate_son bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:enchanting/fortunate_son
execute if score blazeandcave:enchanting/knocking_your_socks_off bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:enchanting/knocking_your_socks_off
execute if score blazeandcave:enchanting/let_it_go bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:enchanting/let_it_go
execute if score blazeandcave:enchanting/librarian bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:enchanting/librarian
execute if score blazeandcave:enchanting/like_a_cat bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:enchanting/like_a_cat
execute if score blazeandcave:enchanting/master_armorer bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:enchanting/master_armorer
execute if score blazeandcave:enchanting/master_enchanter bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:enchanting/master_enchanter
execute if score blazeandcave:enchanting/master_fisher bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:enchanting/master_fisher
execute if score blazeandcave:enchanting/master_knight bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:enchanting/master_knight
execute if score blazeandcave:enchanting/master_miner bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:enchanting/master_miner
execute if score blazeandcave:enchanting/master_sniper bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:enchanting/master_sniper
execute if score blazeandcave:enchanting/master_tridenteer bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:enchanting/master_tridenteer
execute if score blazeandcave:enchanting/needle_sharp bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:enchanting/needle_sharp
execute if score blazeandcave:enchanting/newtons_flaming_laser_sword bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:enchanting/newtons_flaming_laser_sword
execute if score blazeandcave:enchanting/heavy_metal bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:enchanting/heavy_metal
execute if score blazeandcave:enchanting/overkill bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:enchanting/overkill
execute if score blazeandcave:enchanting/pick_like_silk bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:enchanting/pick_like_silk
execute if score blazeandcave:enchanting/root bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:enchanting/root
execute if score blazeandcave:enchanting/scuba_gear bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:enchanting/scuba_gear
execute if score blazeandcave:enchanting/super_efficient bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:enchanting/super_efficient
execute if score blazeandcave:enchanting/to_infinity_and_beyond bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:enchanting/to_infinity_and_beyond
execute if score blazeandcave:challenges/ultimate_enchanter bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:challenges/ultimate_enchanter
execute if score blazeandcave:enchanting/unbreakable bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:enchanting/unbreakable
execute if score blazeandcave:enchanting/undead_slayer bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:enchanting/undead_slayer
execute if score blazeandcave:enchanting/zeus bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:enchanting/zeus


execute if score blazeandcave:end/anti_gravity_generator bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:end/anti_gravity_generator
execute if score blazeandcave:end/cow_jumped_over_the_moon bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:end/cow_jumped_over_the_moon
execute if score blazeandcave:end/dragon_shield bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:end/dragon_shield
execute if score blazeandcave:end/end_bricks bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:end/end_bricks
execute if score blazeandcave:end/extrabiologist bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:end/extrabiologist
execute if score blazeandcave:end/for_mother_clarence bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:end/for_mother_clarence
execute if score blazeandcave:end/getting_chorus bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:end/getting_chorus
execute if score blazeandcave:end/im_coming_back_murph bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:end/im_coming_back_murph
execute if score blazeandcave:end/no_dont_let_me_leave_murph bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:end/no_dont_let_me_leave_murph
execute if score blazeandcave:end/off_with_his_head bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:end/off_with_his_head
execute if score blazeandcave:end/portable_storage bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:end/portable_storage
execute if score blazeandcave:end/purpurfect bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:end/purpurfect
execute if score blazeandcave:end/shouldnt_my_shield_levitate_too bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:end/shouldnt_my_shield_levitate_too
execute if score blazeandcave:end/shulker_breaker bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:end/shulker_breaker
execute if score blazeandcave:end/sky_high bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:end/sky_high
execute if score blazeandcave:end/some_breakthrough bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:end/some_breakthrough
execute if score blazeandcave:end/somewhere_over_the_rainbow bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:end/somewhere_over_the_rainbow
execute if score blazeandcave:end/the_point_of_no_return bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:end/the_point_of_no_return
execute if score blazeandcave:end/the_start_of_something bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:end/the_start_of_something
execute if score blazeandcave:end/uh_houston_we_have_a_problem bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:end/uh_houston_we_have_a_problem
execute if score blazeandcave:end/void_walker bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:end/void_walker


execute if score blazeandcave:potion/furious_ammunition bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:potion/furious_ammunition
execute if score blazeandcave:potion/noxious_fumes bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:potion/noxious_fumes
execute if score blazeandcave:monsters/poison_dart bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:monsters/poison_dart


execute if score blazeandcave:farming/24_carrot_gold bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:farming/24_carrot_gold
execute if score blazeandcave:farming/an_amazing_story bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:farming/an_amazing_story
execute if score blazeandcave:farming/aquatic_biofuel bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:farming/aquatic_biofuel
execute if score blazeandcave:farming/bake_bread bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:farming/bake_bread
execute if score blazeandcave:farming/bapple bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:farming/bapple
execute if score blazeandcave:farming/scientific_inaccuracy bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:farming/scientific_inaccuracy
execute if score blazeandcave:farming/care_for_the_environment bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:farming/care_for_the_environment
execute if score blazeandcave:farming/die_potato bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:farming/die_potato
execute if score blazeandcave:farming/olaf bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:farming/olaf
execute if score blazeandcave:farming/ecologist bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:farming/ecologist
execute if score blazeandcave:farming/hay_there bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:farming/hay_there
execute if score blazeandcave:farming/its_a_cactus bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:farming/its_a_cactus
execute if score blazeandcave:farming/its_full_of_ink bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:farming/its_full_of_ink
execute if score blazeandcave:farming/its_where_nutella_comes_from bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:farming/its_where_nutella_comes_from
execute if score blazeandcave:farming/kelp_me bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:farming/kelp_me
execute if score blazeandcave:farming/me_love_cookie bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:farming/me_love_cookie
execute if score blazeandcave:farming/meat_lovers bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:farming/meat_lovers
execute if score blazeandcave:farming/mega_mushroom bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:farming/mega_mushroom
execute if score blazeandcave:farming/mushroom_mushroom bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:farming/mushroom_mushroom
execute if score blazeandcave:farming/naturally_carved bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:farming/naturally_carved
execute if score blazeandcave:farming/not_today bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:farming/not_today
execute if score blazeandcave:farming/pumpa_kungen bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:farming/pumpa_kungen
execute if score blazeandcave:farming/root bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:farming/root
execute if score blazeandcave:farming/shrooms bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:farming/shrooms
execute if score blazeandcave:farming/souperman bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:farming/souperman
execute if score blazeandcave:farming/spikey bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:farming/spikey
execute if score blazeandcave:farming/sugar_sugar bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:farming/sugar_sugar
execute if score blazeandcave:farming/the_lie bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:farming/the_lie
execute if score blazeandcave:farming/the_melon_the_melon_the_melon bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:farming/the_melon_the_melon_the_melon
execute if score blazeandcave:farming/the_meloncholy_dane bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:farming/the_meloncholy_dane
execute if score blazeandcave:farming/the_pie bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:farming/the_pie
execute if score blazeandcave:farming/ultra_hardcore bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:farming/ultra_hardcore
execute if score blazeandcave:farming/undersea_gardener bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:farming/undersea_gardener
execute if score blazeandcave:farming/vegetarian bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:farming/vegetarian
execute if score blazeandcave:farming/write_your_thoughts bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:farming/write_your_thoughts


execute if score blazeandcave:mining/bling_bling_gone bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:mining/bling_bling_gone
execute if score blazeandcave:mining/coal_miner bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:mining/coal_miner
execute if score blazeandcave:mining/diamond_clad bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:mining/diamond_clad
execute if score blazeandcave:mining/diamond_miner bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:mining/diamond_miner
execute if score blazeandcave:mining/eeuuwww bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:mining/eeuuwww
execute if score blazeandcave:mining/even_moar_tools bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:mining/even_moar_tools
execute if score blazeandcave:mining/flint_miner bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:mining/flint_miner
execute if score blazeandcave:mining/fossil_fuel bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:mining/fossil_fuel
execute if score blazeandcave:mining/gold_mine bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:mining/gold_mine
execute if score blazeandcave:mining/gold_miner bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:mining/gold_miner
execute if score blazeandcave:mining/gold_rush bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:mining/gold_rush
execute if score blazeandcave:mining/hot_topic bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:mining/hot_topic
execute if score blazeandcave:mining/iconic_merchandising_prop bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:mining/iconic_merchandising_prop
execute if score blazeandcave:mining/iron_man bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:mining/iron_man
execute if score blazeandcave:mining/iron_miner bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:mining/iron_miner
execute if score blazeandcave:mining/lapis_lazuli_miner bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:mining/lapis_lazuli_miner
execute if score blazeandcave:mining/living_like_kings bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:mining/living_like_kings
execute if score blazeandcave:mining/master_coal_miner bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:mining/master_coal_miner
execute if score blazeandcave:mining/master_diamond_miner bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:mining/master_diamond_miner
execute if score blazeandcave:mining/master_gold_miner bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:mining/master_gold_miner
execute if score blazeandcave:mining/master_iron_miner bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:mining/master_iron_miner
execute if score blazeandcave:mining/meet_the_flintstones bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:mining/meet_the_flintstones
execute if score blazeandcave:mining/mineral_collection bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:mining/mineral_collection
execute if score blazeandcave:mining/moar_tools bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:mining/moar_tools
execute if score blazeandcave:mining/my_work_here_is_done bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:mining/my_work_here_is_done
execute if score blazeandcave:mining/nananananananana bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:mining/nananananananana
execute if score blazeandcave:mining/obsidian_miner bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:mining/obsidian_miner
execute if score blazeandcave:mining/aww_it_broke bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:mining/aww_it_broke
execute if score blazeandcave:mining/redstone_miner bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:mining/redstone_miner
execute if score blazeandcave:mining/renewable_energy bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:mining/renewable_energy
execute if score blazeandcave:mining/rock_bottom bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:mining/rock_bottom
execute if score blazeandcave:mining/root bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:mining/root
execute if score blazeandcave:mining/seeing_red bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:mining/seeing_red
execute if score blazeandcave:mining/spelunker bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:mining/spelunker
execute if score blazeandcave:mining/stabcraft bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:mining/stabcraft
execute if score blazeandcave:mining/the_mistake bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:mining/the_mistake
execute if score blazeandcave:mining/the_way_to_spawn bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:mining/the_way_to_spawn
execute if score blazeandcave:mining/diam_oh_wait_no bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:mining/diam_oh_wait_no
execute if score blazeandcave:mining/this_is_mine_now bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:mining/this_is_mine_now
execute if score blazeandcave:mining/weve_broken_our_last_shovel bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:mining/weve_broken_our_last_shovel
execute if score blazeandcave:mining/whats_the_time_mr_wolf bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:mining/whats_the_time_mr_wolf


execute if score blazeandcave:nether/basis_of_brewing bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:nether/basis_of_brewing
execute if score blazeandcave:nether/blaze_extinguisher bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:nether/blaze_extinguisher
execute if score blazeandcave:nether/bring_down_the_beast bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:nether/bring_down_the_beast
execute if score blazeandcave:nether/stepping_on_legos bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:nether/stepping_on_legos
execute if score blazeandcave:nether/enders_chest bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:nether/enders_chest
execute if score blazeandcave:nether/fire_blast_shield bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:nether/fire_blast_shield
execute if score blazeandcave:nether/ghast_slayer bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:nether/ghast_slayer
execute if score blazeandcave:nether/giant_floating_jellyfish bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:nether/giant_floating_jellyfish
execute if score blazeandcave:nether/glows_in_the_dark bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:nether/glows_in_the_dark
execute if score blazeandcave:nether/glowstone_miner bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:nether/glowstone_miner
execute if score blazeandcave:nether/high_temperature_fluid_monster bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:nether/high_temperature_fluid_monster
execute if score blazeandcave:nether/limbo_walker bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:nether/limbo_walker
execute if score blazeandcave:nether/magma_cube_squisher bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:nether/magma_cube_squisher
execute if score blazeandcave:nether/quicksand bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:nether/quicksand
execute if score blazeandcave:nether/seeing_stars bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:nether/seeing_stars
execute if score blazeandcave:nether/the_hunt_begins bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:nether/the_hunt_begins
execute if score blazeandcave:nether/the_nethers_shield bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:nether/the_nethers_shield
execute if score blazeandcave:nether/the_tribal_snouts bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:nether/the_tribal_snouts


execute if score blazeandcave:potion/a_much_more_doable_challenge bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:potion/a_much_more_doable_challenge
execute if score blazeandcave:potion/a_weak_brew bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:potion/a_weak_brew
execute if score blazeandcave:potion/death_by_magic bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:potion/death_by_magic
execute if score blazeandcave:potion/hopping_mad bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:potion/hopping_mad
execute if score blazeandcave:potion/hyper_healing bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:potion/hyper_healing
execute if score blazeandcave:potion/medic bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:potion/medic
execute if score blazeandcave:potion/marine_marauder bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:potion/marine_marauder
execute if score blazeandcave:potion/nocturnal bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:potion/nocturnal
execute if score blazeandcave:potion/performance_enhancing_drugs bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:potion/performance_enhancing_drugs
execute if score blazeandcave:potion/root bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:potion/root
execute if score blazeandcave:potion/stayin_frosty bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:potion/stayin_frosty
execute if score blazeandcave:potion/super_strength bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:potion/super_strength
execute if score blazeandcave:potion/tank bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:potion/tank
execute if score blazeandcave:potion/the_invisible_player bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:potion/the_invisible_player
execute if score blazeandcave:potion/true_feather_falling bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:potion/true_feather_falling


execute if score blazeandcave:redstone/bling_plate bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:redstone/bling_plate
execute if score blazeandcave:redstone/comparing_comparator bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:redstone/comparing_comparator
execute if score blazeandcave:redstone/fuel_engine bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:redstone/fuel_engine
execute if score blazeandcave:redstone/dispense_with_this bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:redstone/dispense_with_this
execute if score blazeandcave:redstone/electric_rails bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:redstone/electric_rails
execute if score blazeandcave:redstone/engineer bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:redstone/engineer
execute if score blazeandcave:redstone/master_engineer bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:redstone/master_engineer
execute if score blazeandcave:redstone/metal_plate bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:redstone/metal_plate
execute if score blazeandcave:redstone/mobile_explosion bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:redstone/mobile_explosion
execute if score blazeandcave:redstone/moving_moving_storage bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:redstone/moving_moving_storage
execute if score blazeandcave:redstone/moving_parts bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:redstone/moving_parts
execute if score blazeandcave:redstone/moving_storage bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:redstone/moving_storage
execute if score blazeandcave:redstone/mozart bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:redstone/mozart
execute if score blazeandcave:redstone/observer_buddy bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:redstone/observer_buddy
execute if score blazeandcave:redstone/all_aboard bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:redstone/all_aboard
execute if score blazeandcave:redstone/powerful_light bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:redstone/powerful_light
execute if score blazeandcave:redstone/pressure_detector bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:redstone/pressure_detector
execute if score blazeandcave:redstone/quartz_miner bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:redstone/quartz_miner
execute if score blazeandcave:redstone/quirky_quartz bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:redstone/quirky_quartz
execute if score blazeandcave:redstone/railwayman bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:redstone/railwayman
execute if score blazeandcave:redstone/repeating_repeater bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:redstone/repeating_repeater
execute if score blazeandcave:redstone/root bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:redstone/root
execute if score blazeandcave:redstone/solar_power bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:redstone/solar_power
execute if score blazeandcave:redstone/space_dropper bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:redstone/space_dropper
execute if score blazeandcave:redstone/space_hopper bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:redstone/space_hopper
execute if score blazeandcave:redstone/sticky_parts bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:redstone/sticky_parts
execute if score blazeandcave:redstone/tripping_over bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:redstone/tripping_over
execute if score blazeandcave:redstone/troll_chest bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:redstone/troll_chest
execute if score blazeandcave:redstone/under_pressure bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:redstone/under_pressure


execute if score blazeandcave:weaponry/bombs_away bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:weaponry/bombs_away
execute if score blazeandcave:weaponry/bow_spammer bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:weaponry/bow_spammer
execute if score blazeandcave:weaponry/egging_dude bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:weaponry/egging_dude
execute if score blazeandcave:weaponry/fireworks_display bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:weaponry/fireworks_display
execute if score blazeandcave:weaponry/point_blank bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:weaponry/point_blank
execute if score blazeandcave:weaponry/poseidon_vs_hades bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:weaponry/poseidon_vs_hades
execute if score blazeandcave:weaponry/root bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:weaponry/root
execute if score blazeandcave:weaponry/snowball_fight bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:weaponry/snowball_fight
execute if score blazeandcave:weaponry/the_aquatic_hunter bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:weaponry/the_aquatic_hunter
execute if score blazeandcave:weaponry/the_mighty_hunter bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:weaponry/the_mighty_hunter
execute if score blazeandcave:weaponry/king_of_the_sea bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:weaponry/king_of_the_sea


execute if score minecraft:adventure/adventuring_time bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:adventure/adventuring_time
execute if score minecraft:adventure/kill_a_mob bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:adventure/kill_a_mob
execute if score minecraft:adventure/kill_all_mobs bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:adventure/kill_all_mobs
execute if score minecraft:adventure/root bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:adventure/root
execute if score minecraft:adventure/shoot_arrow bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:adventure/shoot_arrow
execute if score minecraft:adventure/sleep_in_bed bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:adventure/sleep_in_bed
execute if score minecraft:adventure/sniper_duel bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:adventure/sniper_duel
execute if score minecraft:adventure/summon_iron_golem bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:adventure/summon_iron_golem
execute if score minecraft:adventure/throw_trident bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:adventure/throw_trident
execute if score minecraft:adventure/totem_of_undying bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:adventure/totem_of_undying
execute if score minecraft:adventure/trade bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:adventure/trade
execute if score minecraft:adventure/very_very_frightening bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:adventure/very_very_frightening
execute if score minecraft:adventure/two_birds_one_arrow bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:adventure/two_birds_one_arrow
execute if score minecraft:adventure/ol_betsy bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:adventure/ol_betsy
execute if score minecraft:adventure/whos_the_pillager_now bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:adventure/whos_the_pillager_now
execute if score minecraft:adventure/arbalistic bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:adventure/arbalistic


execute if score minecraft:end/dragon_breath bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:end/dragon_breath
execute if score minecraft:end/dragon_egg bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:end/dragon_egg
execute if score minecraft:end/elytra bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:end/elytra
execute if score minecraft:end/enter_end_gateway bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:end/enter_end_gateway
execute if score minecraft:end/find_end_city bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:end/find_end_city
execute if score minecraft:end/kill_dragon bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:end/kill_dragon
execute if score minecraft:end/levitate bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:end/levitate
execute if score minecraft:end/respawn_dragon bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:end/respawn_dragon
execute if score minecraft:end/root bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:end/root


execute if score minecraft:husbandry/balanced_diet bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:husbandry/balanced_diet
execute if score minecraft:husbandry/break_diamond_hoe bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:husbandry/break_diamond_hoe
execute if score minecraft:husbandry/bred_all_animals bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:husbandry/bred_all_animals
execute if score minecraft:husbandry/breed_an_animal bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:husbandry/breed_an_animal
execute if score minecraft:husbandry/fishy_business bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:husbandry/fishy_business
execute if score minecraft:husbandry/plant_seed bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:husbandry/plant_seed
execute if score minecraft:husbandry/root bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:husbandry/root
execute if score minecraft:husbandry/tactical_fishing bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:husbandry/tactical_fishing
execute if score minecraft:husbandry/tame_an_animal bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:husbandry/tame_an_animal
execute if score minecraft:husbandry/complete_catalogue bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:husbandry/complete_catalogue


execute if score minecraft:nether/all_effects bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:nether/all_effects
execute if score minecraft:nether/all_potions bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:nether/all_potions
execute if score minecraft:nether/brew_potion bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:nether/brew_potion
execute if score minecraft:nether/create_beacon bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:nether/create_beacon
execute if score minecraft:nether/create_full_beacon bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:nether/create_full_beacon
execute if score minecraft:nether/fast_travel bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:nether/fast_travel
execute if score minecraft:nether/find_fortress bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:nether/find_fortress
execute if score minecraft:nether/get_wither_skull bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:nether/get_wither_skull
execute if score minecraft:nether/obtain_blaze_rod bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:nether/obtain_blaze_rod
execute if score minecraft:nether/return_to_sender bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:nether/return_to_sender
execute if score minecraft:nether/root bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:nether/root
execute if score minecraft:nether/summon_wither bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:nether/summon_wither
execute if score minecraft:nether/uneasy_alliance bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:nether/uneasy_alliance


execute if score minecraft:story/cure_zombie_villager bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:story/cure_zombie_villager
execute if score minecraft:story/deflect_arrow bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:story/deflect_arrow
execute if score minecraft:story/enchant_item bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:story/enchant_item
execute if score minecraft:story/enter_the_end bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:story/enter_the_end
execute if score minecraft:story/enter_the_nether bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:story/enter_the_nether
execute if score minecraft:story/follow_ender_eye bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:story/follow_ender_eye
execute if score minecraft:story/form_obsidian bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:story/form_obsidian
execute if score minecraft:story/iron_tools bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:story/iron_tools
execute if score minecraft:story/lava_bucket bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:story/lava_bucket
execute if score minecraft:story/mine_diamond bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:story/mine_diamond
execute if score minecraft:story/mine_stone bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:story/mine_stone
execute if score minecraft:story/obtain_armor bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:story/obtain_armor
execute if score blazeandcave:bacap/benchmarking bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:story/root
execute if score minecraft:story/shiny_gear bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:story/shiny_gear
execute if score minecraft:story/smelt_iron bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:story/smelt_iron
execute if score minecraft:story/upgrade_tools bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:story/upgrade_tools

# The following advancements were added in version 1.6
execute if score blazeandcave:adventure/oh_look_it_dings bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/oh_look_it_dings
execute if score blazeandcave:adventure/mapmakers_table bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/mapmakers_table
execute if score blazeandcave:adventure/all_chained_up bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/all_chained_up
execute if score blazeandcave:adventure/retro_future_knight bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/retro_future_knight
execute if score blazeandcave:adventure/crazy_cat_lady bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/crazy_cat_lady
execute if score blazeandcave:adventure/the_tribal_villagers bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/the_tribal_villagers
execute if score blazeandcave:adventure/lilypad_hatter bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/lilypad_hatter
execute if score blazeandcave:challenges/stockbroker bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:challenges/stockbroker
execute if score blazeandcave:adventure/you_are_the_pillager bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/you_are_the_pillager
execute if score blazeandcave:adventure/traveller bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/traveller
execute if score blazeandcave:adventure/shady_deals bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/shady_deals
execute if score blazeandcave:adventure/florist bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/florist
execute if score blazeandcave:adventure/rebuilding_the_oceans bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/rebuilding_the_oceans
execute if score blazeandcave:adventure/deals_off bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/deals_off
execute if score blazeandcave:adventure/out_of_posts bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/out_of_posts
execute if score minecraft:adventure/voluntary_exile bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:adventure/voluntary_exile
execute if score blazeandcave:adventure/riot_shield bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/riot_shield
execute if score blazeandcave:adventure/its_so_beast_like bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/its_so_beast_like
execute if score blazeandcave:adventure/i_am_ravager_hear_me_roar bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/i_am_ravager_hear_me_roar
execute if score blazeandcave:adventure/picador bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/picador
execute if score blazeandcave:adventure/war_is_coming bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/war_is_coming
execute if score blazeandcave:adventure/feeling_ill bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/feeling_ill
execute if score blazeandcave:adventure/professional bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/professional
execute if score blazeandcave:adventure/master_trader bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/master_trader
execute if score blazeandcave:adventure/village_settler bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/village_settler
execute if score blazeandcave:adventure/town_planner bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/town_planner
execute if score minecraft:adventure/hero_of_the_village bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:adventure/hero_of_the_village
execute if score blazeandcave:adventure/veteran_of_the_village bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/veteran_of_the_village

execute if score blazeandcave:animal/cool_kids bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/cool_kids
execute if score blazeandcave:animal/fashion_statement bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/fashion_statement
execute if score blazeandcave:animal/shoe_shed bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/shoe_shed
execute if score blazeandcave:animal/which_came_first bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/which_came_first
execute if score blazeandcave:animal/horse_armorer bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/horse_armorer
execute if score blazeandcave:animal/colorful_cavalry bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/colorful_cavalry
execute if score blazeandcave:animal/master_farrier bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/master_farrier
execute if score blazeandcave:biomes/birdkeeper bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:biomes/birdkeeper
execute if score blazeandcave:animal/llama_llama_duck_king bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/llama_llama_duck_king
execute if score blazeandcave:animal/bunny_lover bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/bunny_lover
execute if score blazeandcave:animal/what_does_the_fox_say bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/what_does_the_fox_say
execute if score blazeandcave:animal/snow_fox_64 bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/snow_fox_64
execute if score blazeandcave:animal/mushroom_scientist bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/mushroom_scientist

execute if score blazeandcave:biomes/for_you_my_sweet bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:biomes/for_you_my_sweet
execute if score blazeandcave:biomes/the_mighty_jungle bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:biomes/the_mighty_jungle
execute if score blazeandcave:biomes/simba bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:biomes/simba
execute if score blazeandcave:biomes/bamboom bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:biomes/bamboom
execute if score blazeandcave:biomes/construction_worker bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:biomes/construction_worker
execute if score blazeandcave:biomes/top_of_the_world bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:biomes/top_of_the_world
execute if score blazeandcave:biomes/zoologist bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:biomes/zoologist
execute if score blazeandcave:biomes/kung_fu_panda bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:biomes/kung_fu_panda

execute if score blazeandcave:building/crazy_walls bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:building/crazy_walls
execute if score blazeandcave:building/barrel_rider bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:building/barrel_rider
execute if score blazeandcave:building/writers_block bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:building/writers_block
execute if score blazeandcave:building/prepare_to_meet_your_loom bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:building/prepare_to_meet_your_loom
execute if score blazeandcave:building/fruit_of_the_looms bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:building/fruit_of_the_looms
execute if score blazeandcave:building/festival_of_lights bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:building/festival_of_lights

execute if score blazeandcave:monsters/ooh_baby bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:monsters/ooh_baby
execute if score blazeandcave:monsters/baby_baby_baby_noo bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:monsters/baby_baby_baby_noo
execute if score blazeandcave:nether/legend_of_hell_chicken_riders bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:nether/legend_of_hell_chicken_riders
execute if score blazeandcave:monsters/custom_boss_fight bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:monsters/custom_boss_fight
execute if score blazeandcave:monsters/mollusc_man bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:monsters/mollusc_man
execute if score blazeandcave:monsters/captain_etho bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:monsters/captain_etho
execute if score blazeandcave:monsters/trick_or_treat bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:monsters/trick_or_treat
execute if score blazeandcave:monsters/handsome_jack bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:monsters/handsome_jack

execute if score blazeandcave:enchanting/machine_bow bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:enchanting/machine_bow
execute if score blazeandcave:enchanting/shotbow bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:enchanting/shotbow
execute if score blazeandcave:enchanting/master_arbalist bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:enchanting/master_arbalist
execute if score blazeandcave:mining/emerald_miner bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:mining/emerald_miner

execute if score blazeandcave:end/the_actual_end bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:end/the_actual_end
execute if score blazeandcave:end/the_beginning bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:end/the_beginning

execute if score blazeandcave:farming/berry_nice bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:farming/berry_nice
execute if score blazeandcave:farming/disen_berry_berry_bad bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:farming/disen_berry_berry_bad
execute if score blazeandcave:farming/suspicious_looking_stew bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:farming/suspicious_looking_stew
execute if score blazeandcave:farming/im_gonna_be_sick bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:farming/im_gonna_be_sick
execute if score blazeandcave:farming/the_garbage_will_do bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:farming/the_garbage_will_do

execute if score blazeandcave:building/camping_out bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:building/camping_out
execute if score blazeandcave:building/spawn_camping bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:building/spawn_camping
execute if score blazeandcave:mining/smokin_hot bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:mining/smokin_hot
execute if score blazeandcave:mining/not_chicken_mcnuggets bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:mining/not_chicken_mcnuggets
execute if score blazeandcave:building/its_original_form bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:building/its_original_form
execute if score blazeandcave:building/smooth_dude bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:building/smooth_dude
execute if score blazeandcave:building/blast_it bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:building/blast_it
execute if score blazeandcave:building/sharpening_station bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:building/sharpening_station
execute if score blazeandcave:building/agent_smithing_table bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:building/agent_smithing_table
execute if score blazeandcave:building/classic_pocket_edition_block bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:building/classic_pocket_edition_block
execute if score blazeandcave:adventure/beethoven bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/beethoven
execute if score blazeandcave:mining/rest_in_pickaxes bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:mining/rest_in_pickaxes
execute if score blazeandcave:mining/moar_broken_tools bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:mining/moar_broken_tools
execute if score blazeandcave:mining/where_are_all_your_clothes bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:mining/where_are_all_your_clothes

execute if score blazeandcave:nether/hells_bells bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:nether/hells_bells
execute if score blazeandcave:nether/decaying_beauty bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:nether/decaying_beauty

execute if score blazeandcave:potion/gas bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:potion/gas

execute if score blazeandcave:weaponry/x_bow bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:weaponry/x_bow
execute if score blazeandcave:weaponry/explosive_fire bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:weaponry/explosive_fire
execute if score blazeandcave:weaponry/that_is_so_fletch bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:weaponry/that_is_so_fletch
execute if score blazeandcave:weaponry/revenge bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:weaponry/revenge
execute if score blazeandcave:weaponry/demolitions_expert bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:weaponry/demolitions_expert
execute if score blazeandcave:weaponry/a_snowballs_chance_in_hell bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:weaponry/a_snowballs_chance_in_hell
execute if score blazeandcave:weaponry/theres_yolk_on_my_head bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:weaponry/theres_yolk_on_my_head
execute if score blazeandcave:weaponry/sir_knight bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:weaponry/sir_knight
execute if score blazeandcave:weaponry/flying_colors bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:weaponry/flying_colors
execute if score blazeandcave:weaponry/shield_luck bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:weaponry/shield_luck
execute if score blazeandcave:weaponry/master_shieldsman bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:weaponry/master_shieldsman
execute if score blazeandcave:weaponry/viking bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:weaponry/viking
execute if score blazeandcave:weaponry/axeman bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:weaponry/axeman
execute if score blazeandcave:weaponry/shovel_knight bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:weaponry/shovel_knight
execute if score blazeandcave:weaponry/expelliarmus bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:weaponry/expelliarmus
execute if score blazeandcave:weaponry/slapfish bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:weaponry/slapfish
execute if score blazeandcave:weaponry/diemonds bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:weaponry/diemonds
execute if score blazeandcave:weaponry/pig_fishing_tournament bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:weaponry/pig_fishing_tournament
execute if score blazeandcave:weaponry/indiana_jones bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:weaponry/indiana_jones
execute if score blazeandcave:weaponry/when_pigs_finally_fly bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:weaponry/when_pigs_finally_fly

# The following advancements were added in version 1.7
execute if score blazeandcave:building/i_dont_like_sand bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:building/i_dont_like_sand
execute if score blazeandcave:building/insomniac bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:building/insomniac
execute if score blazeandcave:building/art_gallery bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:building/art_gallery

execute if score blazeandcave:mining/chestful_of_cobblestone bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:mining/chestful_of_cobblestone
execute if score blazeandcave:building/bubble_bubble_toil_and_trouble bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:building/bubble_bubble_toil_and_trouble
execute if score blazeandcave:building/washing_machine bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:building/washing_machine

execute if score blazeandcave:farming/must_be_your_birthday bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:farming/must_be_your_birthday
execute if score blazeandcave:farming/castaway bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:farming/castaway

execute if score blazeandcave:biomes/free_diver bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:biomes/free_diver
execute if score blazeandcave:biomes/sleep_with_the_fishes bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:biomes/sleep_with_the_fishes
execute if score blazeandcave:biomes/qinling bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:biomes/qinling

execute if score blazeandcave:adventure/were_being_attacked bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/were_being_attacked
execute if score blazeandcave:adventure/superhero_of_the_village bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/superhero_of_the_village

execute if score blazeandcave:monsters/aww_man bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:monsters/aww_man
execute if score blazeandcave:monsters/spider_skeleton bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:monsters/spider_skeleton
execute if score blazeandcave:monsters/oh_no_guys_im_oozing bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:monsters/oh_no_guys_im_oozing

execute if score blazeandcave:weaponry/artillery bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:weaponry/artillery

execute if score blazeandcave:enchanting/magical_stockpile bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:enchanting/magical_stockpile

execute if score blazeandcave:statistics/root bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:statistics/root
execute if score blazeandcave:statistics/out_for_a_stroll bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:statistics/out_for_a_stroll
execute if score blazeandcave:statistics/who_needs_cars bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:statistics/who_needs_cars
execute if score blazeandcave:statistics/i_enjoy_long_walks_and_playing_minecraft bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:statistics/i_enjoy_long_walks_and_playing_minecraft
execute if score blazeandcave:statistics/marathon bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:statistics/marathon
execute if score blazeandcave:statistics/your_legs_must_be_tired bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:statistics/your_legs_must_be_tired
execute if score blazeandcave:statistics/natural_sprinter bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:statistics/natural_sprinter
execute if score blazeandcave:statistics/spring_in_your_step bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:statistics/spring_in_your_step
execute if score blazeandcave:statistics/boing_boing bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:statistics/boing_boing
execute if score blazeandcave:statistics/jumping_jacks bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:statistics/jumping_jacks
execute if score blazeandcave:statistics/sneaky_snitch bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:statistics/sneaky_snitch
execute if score blazeandcave:statistics/black_belt_ninja bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:statistics/black_belt_ninja
execute if score blazeandcave:statistics/ancient_kung_fu_master bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:statistics/ancient_kung_fu_master
execute if score blazeandcave:statistics/laps_in_the_pool bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:statistics/laps_in_the_pool
execute if score blazeandcave:statistics/olympic_athlete bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:statistics/olympic_athlete
execute if score blazeandcave:statistics/olympic_gold_medallist bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:statistics/olympic_gold_medallist
execute if score blazeandcave:statistics/minecart_rider bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:statistics/minecart_rider
execute if score blazeandcave:statistics/i_like_trains bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:statistics/i_like_trains
execute if score blazeandcave:statistics/global_railway_network bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:statistics/global_railway_network
execute if score blazeandcave:statistics/pig_training bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:statistics/pig_training
execute if score blazeandcave:statistics/snout_500 bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:statistics/snout_500
execute if score blazeandcave:statistics/lightning_mcpig bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:statistics/lightning_mcpig
execute if score blazeandcave:statistics/horse_training bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:statistics/horse_training
execute if score blazeandcave:statistics/sheriff_firearm bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:statistics/sheriff_firearm
execute if score blazeandcave:statistics/scourge_of_the_west bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:statistics/scourge_of_the_west
execute if score blazeandcave:statistics/luxury_cruise bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:statistics/luxury_cruise
execute if score blazeandcave:statistics/pirate_captain bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:statistics/pirate_captain
execute if score blazeandcave:statistics/sailor_of_the_seven_seas bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:statistics/sailor_of_the_seven_seas
execute if score blazeandcave:statistics/take_to_the_skies bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:statistics/take_to_the_skies
execute if score blazeandcave:statistics/supersonic bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:statistics/supersonic
execute if score blazeandcave:statistics/frequent_flyer bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:statistics/frequent_flyer
execute if score blazeandcave:statistics/the_parrots_and_the_bats bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:statistics/the_parrots_and_the_bats
execute if score blazeandcave:statistics/cupid bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:statistics/cupid
execute if score blazeandcave:statistics/overpopulation bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:statistics/overpopulation
execute if score blazeandcave:statistics/novice_enchanter bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:statistics/novice_enchanter
execute if score blazeandcave:statistics/journeyman_enchanter bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:statistics/journeyman_enchanter
execute if score blazeandcave:statistics/elderly_enchanter bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:statistics/elderly_enchanter
execute if score blazeandcave:statistics/level_up bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:statistics/level_up
execute if score blazeandcave:statistics/overlevelling bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:statistics/overlevelling
execute if score blazeandcave:statistics/xp_grinder bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:statistics/xp_grinder
execute if score blazeandcave:statistics/the_first_night bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:statistics/the_first_night
execute if score blazeandcave:statistics/passing_the_time bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:statistics/passing_the_time
execute if score blazeandcave:statistics/happy_new_year bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:statistics/happy_new_year

execute if score blazeandcave:potion/mad_scientist bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:potion/mad_scientist
execute if score blazeandcave:potion/a_furious_test_subject bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:potion/a_furious_test_subject

execute if score blazeandcave:end/event_horizon bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:end/event_horizon
execute if score blazeandcave:end/dragon_vs_dragon bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:end/dragon_vs_dragon
execute if score blazeandcave:end/rocketman bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:end/rocketman

execute if score blazeandcave:challenges/root bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:challenges/root
execute if score blazeandcave:challenges/all_the_blocks bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:challenges/all_the_blocks
execute if score blazeandcave:challenges/all_the_items bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:challenges/all_the_items
execute if score blazeandcave:challenges/stack_all_the_blocks bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:challenges/stack_all_the_blocks
execute if score blazeandcave:challenges/stack_all_the_items bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:challenges/stack_all_the_items
execute if score blazeandcave:challenges/potion_master bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:challenges/potion_master
execute if score blazeandcave:challenges/biological_warfare bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:challenges/biological_warfare
execute if score blazeandcave:challenges/global_vaccination bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:challenges/global_vaccination
execute if score blazeandcave:challenges/death_from_all bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:challenges/death_from_all
execute if score blazeandcave:challenges/nuclear_fusion bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:challenges/nuclear_fusion
execute if score blazeandcave:challenges/zombie_apocalypse bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:challenges/zombie_apocalypse
execute if score blazeandcave:challenges/rise_of_the_skeletons bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:challenges/rise_of_the_skeletons
execute if score blazeandcave:challenges/creepergeddon bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:challenges/creepergeddon
execute if score blazeandcave:challenges/dragon_army bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:challenges/dragon_army
execute if score blazeandcave:challenges/the_world_is_ending bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:challenges/the_world_is_ending
execute if score blazeandcave:challenges/warlock bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:challenges/warlock
execute if score blazeandcave:challenges/were_in_the_endgame_now bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:challenges/were_in_the_endgame_now
execute if score blazeandcave:challenges/immortal bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:challenges/immortal
execute if score blazeandcave:challenges/abyss_lord bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:challenges/abyss_lord
execute if score blazeandcave:challenges/a_million_blocks_away bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:challenges/a_million_blocks_away
execute if score blazeandcave:challenges/highway_to_hell bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:challenges/highway_to_hell
execute if score blazeandcave:challenges/endergeddon bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:challenges/endergeddon
execute if score blazeandcave:challenges/im_in_space bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:challenges/im_in_space
execute if score blazeandcave:challenges/dragon_vs_dragon_ii_electric_boogaloo bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:challenges/dragon_vs_dragon_ii_electric_boogaloo

# The following advancements were added in version 1.8
execute if score blazeandcave:animal/ya_like_jazz bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/ya_like_jazz
execute if score minecraft:husbandry/safely_harvest_honey bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:husbandry/safely_harvest_honey
execute if score blazeandcave:animal/winnie_the_pooh bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/winnie_the_pooh
execute if score minecraft:adventure/honey_block_slide bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:adventure/honey_block_slide
execute if score blazeandcave:animal/wheres_the_honey_lebowski bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/wheres_the_honey_lebowski
execute if score blazeandcave:animal/hive_mind bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/hive_mind
execute if score minecraft:husbandry/silk_touch_nest bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:husbandry/silk_touch_nest
execute if score blazeandcave:animal/honey_im_home bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/honey_im_home
execute if score blazeandcave:animal/not_the_bees bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/not_the_bees

execute if score blazeandcave:building/and_open bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:building/and_open
execute if score blazeandcave:building/stairs_no bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:building/stairs_no
execute if score blazeandcave:building/cut_in_half bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:building/cut_in_half

execute if score blazeandcave:biomes/everybody_loves_ice bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:biomes/everybody_loves_ice

execute if score blazeandcave:farming/full_stomach bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:farming/full_stomach

execute if score blazeandcave:mining/heart_of_darkness bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:mining/heart_of_darkness

execute if score blazeandcave:nether/im_in_lava_with_you bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:nether/im_in_lava_with_you

# The following advancements were added in version 1.9
execute if score blazeandcave:bacap/adventure_milestone bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:bacap/adventure_milestone
execute if score blazeandcave:bacap/animal_milestone bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:bacap/animal_milestone
execute if score blazeandcave:bacap/biomes_milestone bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:bacap/biomes_milestone
execute if score blazeandcave:bacap/building_milestone bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:bacap/building_milestone
execute if score blazeandcave:bacap/challenges_milestone bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:bacap/challenges_milestone
execute if score blazeandcave:bacap/enchanting_milestone bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:bacap/enchanting_milestone
execute if score blazeandcave:bacap/end_milestone bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:bacap/end_milestone
execute if score blazeandcave:bacap/farming_milestone bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:bacap/farming_milestone
execute if score blazeandcave:bacap/mining_milestone bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:bacap/mining_milestone
execute if score blazeandcave:bacap/monsters_milestone bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:bacap/monsters_milestone
execute if score blazeandcave:bacap/nether_milestone bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:bacap/nether_milestone
execute if score blazeandcave:bacap/potion_milestone bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:bacap/potion_milestone
execute if score blazeandcave:bacap/redstone_milestone bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:bacap/redstone_milestone
execute if score blazeandcave:bacap/statistics_milestone bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:bacap/statistics_milestone
execute if score blazeandcave:bacap/weaponry_milestone bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:bacap/weaponry_milestone
execute if score blazeandcave:bacap/advancement_legend bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:bacap/advancement_legend

# The following advancements were added in version 1.10
execute if score blazeandcave:mining/dungeons_and_spawners bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:mining/dungeons_and_spawners
execute if score blazeandcave:mining/steals_on_wheels bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:mining/steals_on_wheels
execute if score blazeandcave:building/delicious_hot_schmoes bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:building/delicious_hot_schmoes
execute if score blazeandcave:mining/oresome bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:mining/oresome

execute if score blazeandcave:building/grass_type bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:building/grass_type
execute if score blazeandcave:building/shroom_lightyear bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:building/shroom_lightyear
execute if score blazeandcave:building/cerulean bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:building/cerulean
execute if score blazeandcave:building/let_there_be_light bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:building/let_there_be_light
execute if score blazeandcave:building/no_chain_no_gain bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:building/no_chain_no_gain
execute if score blazeandcave:building/blackstonehenge bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:building/blackstonehenge
execute if score blazeandcave:building/colors_of_the_wind bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:building/colors_of_the_wind

execute if score blazeandcave:farming/a_gluttonous_diet bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:farming/a_gluttonous_diet
execute if score blazeandcave:farming/natural_fertiliser bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:farming/natural_fertiliser
execute if score blazeandcave:farming/combine_harvester bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:farming/combine_harvester
execute if score blazeandcave:farming/whats_new_with_composting bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:farming/whats_new_with_composting

execute if score blazeandcave:farming/foliage bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:farming/foliage
execute if score blazeandcave:animal/going_down_the_rabbit_hole bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/going_down_the_rabbit_hole
execute if score blazeandcave:animal/just_keeps_going bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/just_keeps_going
execute if score blazeandcave:animal/nest_quick bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/nest_quick
execute if score blazeandcave:animal/heavy_duty_caravan bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/heavy_duty_caravan
execute if score blazeandcave:animal/save_the_turtles bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/save_the_turtles

execute if score blazeandcave:biomes/so_long_and_thanks_for_all_the_fish bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:biomes/so_long_and_thanks_for_all_the_fish

execute if score blazeandcave:adventure/now_youre_thinking_with_portals bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/now_youre_thinking_with_portals
execute if score blazeandcave:adventure/i_just_want_to_make_toast bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/i_just_want_to_make_toast
execute if score blazeandcave:adventure/whats_up_doc bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/whats_up_doc
execute if score blazeandcave:adventure/nyan_sheep bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/nyan_sheep
execute if score blazeandcave:adventure/slenderman bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/slenderman
execute if score blazeandcave:adventure/the_one_and_true_johnny bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/the_one_and_true_johnny
execute if score blazeandcave:adventure/prime_specimen bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/prime_specimen
execute if score minecraft:adventure/trade_at_world_height bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:adventure/trade_at_world_height
execute if score blazeandcave:adventure/redemption_arc bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/redemption_arc
execute if score blazeandcave:adventure/workaholic bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/workaholic
execute if score blazeandcave:challenges/i_am_loot bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:challenges/i_am_loot

execute if score blazeandcave:monsters/paleontologist bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:monsters/paleontologist
execute if score blazeandcave:monsters/impossible bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:monsters/impossible
execute if score blazeandcave:monsters/family_reunion bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:monsters/family_reunion
execute if score blazeandcave:monsters/bone_to_party bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:monsters/bone_to_party

execute if score blazeandcave:weaponry/loser bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:weaponry/loser
execute if score blazeandcave:weaponry/multiclassed bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:weaponry/multiclassed
execute if score blazeandcave:weaponry/pyrotechnic bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:weaponry/pyrotechnic
execute if score blazeandcave:weaponry/my_eyes bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:weaponry/my_eyes
execute if score blazeandcave:weaponry/who_ya_gonna_call bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:weaponry/who_ya_gonna_call

execute if score blazeandcave:redstone/target_acquired bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:redstone/target_acquired
execute if score minecraft:adventure/bullseye bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:adventure/bullseye
execute if score blazeandcave:redstone/target_practise bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:redstone/target_practise

execute if score blazeandcave:enchanting/this_name_sounds_cooler bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:enchanting/this_name_sounds_cooler
execute if score blazeandcave:enchanting/ill_be_back bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:enchanting/ill_be_back
execute if score blazeandcave:enchanting/god_of_thunder bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:enchanting/god_of_thunder
execute if score blazeandcave:enchanting/a_rather_pointy_fence_post bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:enchanting/a_rather_pointy_fence_post
execute if score blazeandcave:enchanting/gotta_go_fast bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:enchanting/gotta_go_fast
execute if score blazeandcave:enchanting/handmade_blinding bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:enchanting/handmade_blinding
execute if score blazeandcave:enchanting/master_digger bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:enchanting/master_digger
execute if score blazeandcave:enchanting/master_axeman bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:enchanting/master_axeman
execute if score blazeandcave:enchanting/master_farmer bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:enchanting/master_farmer

execute if score blazeandcave:statistics/mob_hunter bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:statistics/mob_hunter
execute if score blazeandcave:statistics/bloodthirsty bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:statistics/bloodthirsty
execute if score blazeandcave:statistics/kill_or_be_killed bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:statistics/kill_or_be_killed
execute if score blazeandcave:statistics/taking_it_in_stride bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:statistics/taking_it_in_stride
execute if score blazeandcave:statistics/who_needs_boats bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:statistics/who_needs_boats
execute if score blazeandcave:statistics/this_ride_is_lit_yo bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:statistics/this_ride_is_lit_yo

execute if score blazeandcave:nether/stem_research bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:nether/stem_research
execute if score blazeandcave:nether/what_a_fungi bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:nether/what_a_fungi
execute if score blazeandcave:nether/i_am_root bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:nether/i_am_root
execute if score blazeandcave:nether/dont_blink bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:nether/dont_blink
execute if score blazeandcave:nether/twisted bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:nether/twisted
execute if score blazeandcave:nether/what_about_corruption_planks bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:nether/what_about_corruption_planks
execute if score blazeandcave:nether/welcome_to_warp_zone bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:nether/welcome_to_warp_zone
execute if score minecraft:nether/explore_nether bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:nether/explore_nether
execute if score blazeandcave:nether/hell_botanist bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:nether/hell_botanist
execute if score blazeandcave:nether/spreading_corruption bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:nether/spreading_corruption
execute if score blazeandcave:nether/the_struggle_nether_ends bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:nether/the_struggle_nether_ends
execute if score blazeandcave:nether/roadhog bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:nether/roadhog
execute if score blazeandcave:nether/when_hoglins_breed bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:nether/when_hoglins_breed
execute if score blazeandcave:nether/whole_hog bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:nether/whole_hog
execute if score blazeandcave:nether/giddy_up bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:nether/giddy_up
execute if score blazeandcave:nether/zork_chop bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:nether/zork_chop
execute if score minecraft:nether/ride_strider bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:nether/ride_strider
execute if score blazeandcave:nether/bobbleheads bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:nether/bobbleheads
execute if score blazeandcave:nether/this_ones_mine bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:nether/this_ones_mine
execute if score minecraft:nether/distract_piglin bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:nether/distract_piglin
execute if score blazeandcave:nether/cultural_misunderstandings bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:nether/cultural_misunderstandings
execute if score minecraft:nether/obtain_crying_obsidian bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:nether/obtain_crying_obsidian
execute if score blazeandcave:nether/anchorman bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:nether/anchorman
execute if score minecraft:nether/charge_respawn_anchor bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:nether/charge_respawn_anchor
execute if score blazeandcave:nether/we_got_a_live_one bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:nether/we_got_a_live_one
execute if score blazeandcave:nether/when_piglins_fly bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:nether/when_piglins_fly
execute if score blazeandcave:nether/electrifying_alliance bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:nether/electrifying_alliance
execute if score blazeandcave:nether/time_to_fire_back bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:nether/time_to_fire_back
execute if score blazeandcave:nether/from_whence_it_came bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:nether/from_whence_it_came
execute if score minecraft:nether/find_bastion bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:nether/find_bastion
execute if score minecraft:nether/loot_bastion bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:nether/loot_bastion
execute if score blazeandcave:nether/gilty bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:nether/gilty
execute if score blazeandcave:nether/wub_wub_wub bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:nether/wub_wub_wub
execute if score blazeandcave:nether/nugget_in_a_biscuit bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:nether/nugget_in_a_biscuit
execute if score blazeandcave:nether/dark_ages bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:nether/dark_ages
execute if score blazeandcave:nether/burnt_right_into_your_soul bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:nether/burnt_right_into_your_soul
execute if score blazeandcave:nether/a_soul_for_a_soul bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:nether/a_soul_for_a_soul
execute if score blazeandcave:nether/let_me_out bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:nether/let_me_out
execute if score blazeandcave:nether/inception bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:nether/inception
execute if score blazeandcave:nether/the_descent bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:nether/the_descent
execute if score minecraft:nether/obtain_ancient_debris bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:nether/obtain_ancient_debris
execute if score blazeandcave:nether/holy_scrap bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:nether/holy_scrap
execute if score blazeandcave:nether/diamonds_are_not_forever bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:nether/diamonds_are_not_forever
execute if score blazeandcave:nether/moar_upgraded_tools bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:nether/moar_upgraded_tools
execute if score minecraft:nether/netherite_armor bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:nether/netherite_armor
execute if score blazeandcave:nether/soul_runnings bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:nether/soul_runnings
execute if score blazeandcave:nether/fool_me_twice bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:nether/fool_me_twice
execute if score blazeandcave:mining/get_a_lode_of_this bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:mining/get_a_lode_of_this
execute if score minecraft:adventure/use_lodestone bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:adventure/use_lodestone
execute if score blazeandcave:mining/lodes_of_applications bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:mining/lodes_of_applications
execute if score blazeandcave:nether/netherite_miner bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:nether/netherite_miner

execute if score blazeandcave:potion/failed_concoctions bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:potion/failed_concoctions

execute if score blazeandcave:end/what_for bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:end/what_for
execute if score blazeandcave:end/ring_of_the_end bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:end/ring_of_the_end
execute if score blazeandcave:end/in_your_face_neil_armstrong bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:end/in_your_face_neil_armstrong
execute if score blazeandcave:end/organizational_wizard bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:end/organizational_wizard
execute if score blazeandcave:end/a_wizards_breakfast bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:end/a_wizards_breakfast

execute if score blazeandcave:challenges/constellation bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:challenges/constellation
execute if score blazeandcave:challenges/hearts_of_the_stack bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:challenges/hearts_of_the_stack
execute if score blazeandcave:challenges/the_devils_distance bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:challenges/the_devils_distance
execute if score blazeandcave:challenges/ad_astra bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:challenges/ad_astra
execute if score blazeandcave:challenges/dragon_vs_wither_the_pre_sequel bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:challenges/dragon_vs_wither_the_pre_sequel

# The following advancements were added in version 1.11
execute if score blazeandcave:bacap/time_to_dig bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:bacap/time_to_dig

execute if score blazeandcave:mining/diamonds_to_you bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:mining/diamonds_to_you

execute if score blazeandcave:building/one_pickle_two_pickle_sea_pickle_four bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:building/one_pickle_two_pickle_sea_pickle_four
execute if score blazeandcave:building/harry_potter bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:building/harry_potter
execute if score blazeandcave:building/armor_display bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:building/armor_display

execute if score blazeandcave:farming/unmasked bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:farming/unmasked

execute if score blazeandcave:animal/delicious_fish bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/delicious_fish
execute if score blazeandcave:animal/milkshroom bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/milkshroom
execute if score blazeandcave:animal/live_and_let_dye bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/live_and_let_dye
execute if score blazeandcave:animal/foxy_thievery bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/foxy_thievery
execute if score blazeandcave:animal/lead_the_way bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/lead_the_way
execute if score blazeandcave:animal/beeloons bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/beeloons
execute if score blazeandcave:animal/follow_the_leader bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/follow_the_leader

execute if score blazeandcave:biomes/echolocation bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:biomes/echolocation
execute if score blazeandcave:biomes/lion_hunter bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:biomes/lion_hunter

execute if score blazeandcave:adventure/your_daily_fix bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/your_daily_fix
execute if score blazeandcave:adventure/im_not_lost_anymore bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/im_not_lost_anymore

execute if score blazeandcave:monsters/controlled_detonation bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:monsters/controlled_detonation
execute if score blazeandcave:monsters/miracle_drink bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:monsters/miracle_drink
execute if score blazeandcave:monsters/dead_really_dont_die bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:monsters/dead_really_dont_die

execute if score blazeandcave:weaponry/half_heart_life bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:weaponry/half_heart_life

execute if score blazeandcave:nether/brute_force bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:nether/brute_force
execute if score blazeandcave:nether/et_tu_brute bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:nether/et_tu_brute
execute if score blazeandcave:nether/hot_reels bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:nether/hot_reels
execute if score blazeandcave:nether/nether_rock_collection bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:nether/nether_rock_collection

# The following advancements were added in version 1.12
execute if score blazeandcave:mining/youll_never_take_me_alive_copper bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:mining/youll_never_take_me_alive_copper
execute if score blazeandcave:mining/budget_channeling bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:mining/budget_channeling
execute if score blazeandcave:mining/dont_come_a_copper bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:mining/dont_come_a_copper
execute if score blazeandcave:mining/copper_miner bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:mining/copper_miner
execute if score blazeandcave:mining/master_copper_miner bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:mining/master_copper_miner
execute if score minecraft:husbandry/wax_on bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:husbandry/wax_on
execute if score blazeandcave:mining/the_statue_of_liberty bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:mining/the_statue_of_liberty
execute if score blazeandcave:mining/sly_copper_the_copper_heist bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:mining/sly_copper_the_copper_heist
execute if score blazeandcave:mining/gi_geode bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:mining/gi_geode
execute if score blazeandcave:mining/good_for_your_bones bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:mining/good_for_your_bones
execute if score blazeandcave:mining/galileo_figaro bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:mining/galileo_figaro
execute if score blazeandcave:mining/blackout bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:mining/blackout
execute if score blazeandcave:mining/amethyst_miner bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:mining/amethyst_miner
execute if score blazeandcave:mining/lichen_subscribe bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:mining/lichen_subscribe
execute if score blazeandcave:mining/thats_the_point bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:mining/thats_the_point
execute if score blazeandcave:mining/deep_slate_nine bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:mining/deep_slate_nine
execute if score blazeandcave:building/tuff_stuff bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:building/tuff_stuff
execute if score blazeandcave:mining/moss_maker bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:mining/moss_maker
execute if score blazeandcave:mining/iggy bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:mining/iggy
execute if score blazeandcave:mining/particle_fan bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:mining/particle_fan
execute if score blazeandcave:mining/lush_hour bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:mining/lush_hour
execute if score blazeandcave:mining/a_shiny_treat bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:mining/a_shiny_treat
execute if score minecraft:husbandry/wax_off bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:husbandry/wax_off
execute if score minecraft:adventure/lightning_rod_with_villager_no_fire bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:adventure/lightning_rod_with_villager_no_fire
execute if score blazeandcave:mining/pixel_perfect bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:mining/pixel_perfect
execute if score blazeandcave:mining/strike_a_light bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:mining/strike_a_light
execute if score blazeandcave:mining/bonfire_night bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:mining/bonfire_night
execute if score blazeandcave:mining/called_shot bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:mining/called_shot
execute if score blazeandcave:mining/bulldozer bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:mining/bulldozer
execute if score blazeandcave:mining/mr_bean bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:mining/mr_bean

execute if score blazeandcave:building/setting_up_the_mood bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:building/setting_up_the_mood
execute if score blazeandcave:building/the_ritual_begins bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:building/the_ritual_begins
execute if score blazeandcave:building/happy_birthday bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:building/happy_birthday
execute if score blazeandcave:building/pane_in_the_glass bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:building/pane_in_the_glass
execute if score blazeandcave:building/hot_tub bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:building/hot_tub
execute if score blazeandcave:building/rock_polish bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:building/rock_polish
execute if score blazeandcave:building/deepslate_conspiracy bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:building/deepslate_conspiracy
execute if score blazeandcave:building/skyblock bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:building/skyblock

execute if score blazeandcave:farming/one_course_meal bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:farming/one_course_meal
execute if score blazeandcave:farming/an_apple_a_day bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:farming/an_apple_a_day
execute if score blazeandcave:farming/come_to_the_countryside bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:farming/come_to_the_countryside

execute if score blazeandcave:animal/goat_out_of_here bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/goat_out_of_here
execute if score blazeandcave:animal/billy_the_kid bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/billy_the_kid
execute if score blazeandcave:animal/goat_simulator bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/goat_simulator
execute if score blazeandcave:animal/cephalight bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/cephalight
execute if score minecraft:husbandry/make_a_sign_glow bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:husbandry/make_a_sign_glow
execute if score blazeandcave:animal/flashy_items bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/flashy_items
execute if score blazeandcave:animal/iceologer_shouldve_won bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/iceologer_shouldve_won
execute if score minecraft:husbandry/axolotl_in_a_bucket bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:husbandry/axolotl_in_a_bucket
execute if score blazeandcave:animal/axolittle bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/axolittle
execute if score blazeandcave:animal/axolotl_of_them bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/axolotl_of_them
execute if score blazeandcave:animal/axeolotl bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/axeolotl
execute if score blazeandcave:animal/thanks_a_lotl bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/thanks_a_lotl
execute if score blazeandcave:animal/humble_bundle bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/humble_bundle
execute if score blazeandcave:animal/fractal bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/fractal
execute if score blazeandcave:animal/swine_sailing bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/swine_sailing
execute if score blazeandcave:animal/llama_festival bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/llama_festival
execute if score blazeandcave:animal/so_hungry_i_could_eat_a_horse bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/so_hungry_i_could_eat_a_horse
execute if score blazeandcave:animal/screaming_milk bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/screaming_milk
execute if score minecraft:husbandry/ride_a_boat_with_a_goat bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:husbandry/ride_a_boat_with_a_goat
execute if score minecraft:husbandry/kill_axolotl_target bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:husbandry/kill_axolotl_target
execute if score minecraft:adventure/spyglass_at_parrot bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:adventure/spyglass_at_parrot

execute if score blazeandcave:biomes/this_snow_is_snowier bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:biomes/this_snow_is_snowier
execute if score blazeandcave:biomes/powder_full bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:biomes/powder_full
execute if score blazeandcave:biomes/pandamonium bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:biomes/pandamonium
execute if score blazeandcave:biomes/edge_of_the_jungle bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:biomes/edge_of_the_jungle
execute if score minecraft:adventure/walk_on_powder_snow_with_leather_boots bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:adventure/walk_on_powder_snow_with_leather_boots
execute if score blazeandcave:biomes/boatception bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:biomes/boatception
execute if score blazeandcave:biomes/smooth_operator bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:biomes/smooth_operator

execute if score blazeandcave:mining/this_dirt_is_dirtier bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:mining/this_dirt_is_dirtier
execute if score blazeandcave:mining/leaflet_drop bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:mining/leaflet_drop
execute if score blazeandcave:adventure/buy_low_sell_high bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/buy_low_sell_high
execute if score blazeandcave:adventure/justice bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/justice
execute if score blazeandcave:adventure/rare_candy_shop bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/rare_candy_shop
execute if score blazeandcave:adventure/hey_you_two_should_kiss bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/hey_you_two_should_kiss

execute if score blazeandcave:monsters/poultry_boy bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:monsters/poultry_boy
execute if score blazeandcave:monsters/basketblock_championship bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:monsters/basketblock_championship
execute if score blazeandcave:monsters/pupil_poppers bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:monsters/pupil_poppers

execute if score blazeandcave:weaponry/its_time_consuming bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:weaponry/its_time_consuming
execute if score blazeandcave:weaponry/inspector_gadget bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:weaponry/inspector_gadget
execute if score blazeandcave:weaponry/rock_paper_shears bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:weaponry/rock_paper_shears
execute if score blazeandcave:weaponry/backfire bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:weaponry/backfire

execute if score blazeandcave:redstone/take_notes bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:redstone/take_notes
execute if score blazeandcave:redstone/noteworthy bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:redstone/noteworthy
execute if score blazeandcave:redstone/travelling_bard bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:redstone/travelling_bard
execute if score blazeandcave:redstone/vibe_check bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:redstone/vibe_check

execute if score blazeandcave:enchanting/over_overkill bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:enchanting/over_overkill

execute if score blazeandcave:statistics/the_haggler bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:statistics/the_haggler
execute if score blazeandcave:statistics/big_spender bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:statistics/big_spender
execute if score blazeandcave:statistics/stonks bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:statistics/stonks

execute if score blazeandcave:nether/ancient_restoration bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:nether/ancient_restoration
execute if score blazeandcave:nether/hot_spring bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:nether/hot_spring
execute if score blazeandcave:nether/polar_opposites bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:nether/polar_opposites
execute if score blazeandcave:nether/jenga bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:nether/jenga
execute if score blazeandcave:nether/instant_mining bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:nether/instant_mining
execute if score blazeandcave:nether/master_netherite_miner bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:nether/master_netherite_miner
execute if score blazeandcave:nether/netherite_mad_lad bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:nether/netherite_mad_lad
execute if score blazeandcave:nether/beacon_overlord bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:nether/beacon_overlord
execute if score minecraft:adventure/spyglass_at_ghast bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:adventure/spyglass_at_ghast
execute if score blazeandcave:nether/a_piglins_best_friend bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:nether/a_piglins_best_friend

execute if score blazeandcave:potion/gas_bomb bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:potion/gas_bomb

execute if score blazeandcave:end/good_luck_getting_this_one bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:end/good_luck_getting_this_one
execute if score minecraft:adventure/spyglass_at_dragon bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:adventure/spyglass_at_dragon

execute if score blazeandcave:challenges/the_perfect_run bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:challenges/the_perfect_run
execute if score blazeandcave:challenges/telescopic bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:challenges/telescopic

# The following advancements were added in version 1.13
execute if score blazeandcave:mining/dripstone_drop bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:mining/dripstone_drop
execute if score blazeandcave:mining/lucky_break bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:mining/lucky_break
execute if score minecraft:adventure/fall_from_world_height bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:adventure/fall_from_world_height
execute if score blazeandcave:mining/bottom_to_top bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:mining/bottom_to_top

execute if score blazeandcave:building/a_good_start bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:building/a_good_start

execute if score blazeandcave:farming/squid_game bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:farming/squid_game

execute if score blazeandcave:animal/blackberry_market bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/blackberry_market

execute if score blazeandcave:biomes/were_going_on_a_bear_hunt bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:biomes/were_going_on_a_bear_hunt
execute if score blazeandcave:biomes/dive_bomb bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:biomes/dive_bomb
execute if score blazeandcave:biomes/captain_america bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:biomes/captain_america

execute if score blazeandcave:adventure/map_room bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/map_room
execute if score blazeandcave:adventure/sound_the_alarm bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/sound_the_alarm
execute if score minecraft:adventure/play_jukebox_in_meadows bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:adventure/play_jukebox_in_meadows

execute if score blazeandcave:redstone/click bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:redstone/click
execute if score blazeandcave:redstone/leveraging_synergy bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:redstone/leveraging_synergy
execute if score blazeandcave:redstone/on_a_rail bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:redstone/on_a_rail

execute if score blazeandcave:enchanting/baron_of_blacksmiths bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:enchanting/baron_of_blacksmiths

execute if score blazeandcave:statistics/65_hours_of_walking bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:statistics/65_hours_of_walking

execute if score minecraft:nether/ride_strider_in_overworld_lava bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:nether/ride_strider_in_overworld_lava
execute if score blazeandcave:nether/gilded_miner bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:nether/gilded_miner
execute if score blazeandcave:nether/astrobrute bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:nether/astrobrute
execute if score blazeandcave:nether/ludicrous_speed bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:nether/ludicrous_speed

execute if score blazeandcave:potion/stealth_takedown bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:potion/stealth_takedown

execute if score blazeandcave:end/dogfight bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:end/dogfight

execute if score blazeandcave:challenges/riddle_me_this bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:challenges/riddle_me_this

# The following advancements are in the Terralith version as of 1.13.1. When running normal BACAP, these commands won't do anything
execute if score blazeandcave:biomes/one_small_steppe_for_man bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:biomes/one_small_steppe_for_man
execute if score blazeandcave:biomes/o_land_o_bloom bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:biomes/o_land_o_bloom
execute if score blazeandcave:biomes/over_the_moon bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:biomes/over_the_moon
execute if score blazeandcave:biomes/smarter_than_the_average_bear bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:biomes/smarter_than_the_average_bear
execute if score blazeandcave:biomes/choco_mountain bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:biomes/choco_mountain
execute if score blazeandcave:biomes/the_world_is_your_canvas bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:biomes/the_world_is_your_canvas
execute if score blazeandcave:biomes/eruption_in_the_air bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:biomes/eruption_in_the_air
execute if score blazeandcave:biomes/skylanders bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:biomes/skylanders
execute if score blazeandcave:biomes/aesthetic bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:biomes/aesthetic
execute if score blazeandcave:biomes/alpha_days bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:biomes/alpha_days
execute if score blazeandcave:biomes/the_boreal_deal bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:biomes/the_boreal_deal
execute if score blazeandcave:biomes/a_grassy_nature bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:biomes/a_grassy_nature
execute if score blazeandcave:biomes/highlander bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:biomes/highlander
execute if score blazeandcave:biomes/bushranger bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:biomes/bushranger
execute if score blazeandcave:biomes/a_cliffhanger bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:biomes/a_cliffhanger
execute if score blazeandcave:biomes/pretty_in_purple bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:biomes/pretty_in_purple
execute if score blazeandcave:biomes/master_spelunker bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:biomes/master_spelunker
execute if score blazeandcave:biomes/terralithic bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:biomes/terralithic

execute if score blazeandcave:biomes/land_of_icicles bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:biomes/land_of_icicles
execute if score blazeandcave:adventure/castle_of_hrrms bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/castle_of_hrrms
execute if score blazeandcave:adventure/remote_shelter bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/remote_shelter
execute if score blazeandcave:adventure/spire_of_ice bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/spire_of_ice
execute if score blazeandcave:adventure/under_the_ice bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/under_the_ice
execute if score blazeandcave:adventure/a_journey_begins bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/a_journey_begins
execute if score blazeandcave:adventure/expedition_of_discovery bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/expedition_of_discovery

# The following advancements were added in version 1.14
execute if score minecraft:adventure/avoid_vibration bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:adventure/avoid_vibration
execute if score minecraft:adventure/kill_mob_near_sculk_catalyst bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:adventure/kill_mob_near_sculk_catalyst
execute if score blazeandcave:mining/shriek_forever_after bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:mining/shriek_forever_after
execute if score blazeandcave:redstone/the_block_of_eternal_screaming bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:redstone/the_block_of_eternal_screaming
execute if score blazeandcave:redstone/cataclyst bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:redstone/cataclyst
execute if score blazeandcave:redstone/monstrous_sacrifices bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:redstone/monstrous_sacrifices
execute if score blazeandcave:redstone/the_incredible_sculk bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:redstone/the_incredible_sculk
execute if score blazeandcave:redstone/sculker_box bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:redstone/sculker_box
execute if score blazeandcave:mining/fallen_kingdom bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:mining/fallen_kingdom
execute if score blazeandcave:mining/frigid_diversions bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:mining/frigid_diversions
execute if score blazeandcave:mining/death_pointer bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:mining/death_pointer
execute if score blazeandcave:mining/9_to_5 bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:mining/9_to_5
execute if score blazeandcave:mining/echonomy bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:mining/echonomy
execute if score blazeandcave:mining/blind_as_a_bat bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:mining/blind_as_a_bat

execute if score blazeandcave:building/stuck_in_the_mud bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:building/stuck_in_the_mud
execute if score blazeandcave:building/elmer_mudd bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:building/elmer_mudd
execute if score blazeandcave:building/mangrove_master bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:building/mangrove_master
execute if score minecraft:husbandry/froglights bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:husbandry/froglights

execute if score blazeandcave:farming/a_mangrove_grove bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:farming/a_mangrove_grove

execute if score blazeandcave:animal/frog_family bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/frog_family
execute if score minecraft:husbandry/tadpole_in_a_bucket bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:husbandry/tadpole_in_a_bucket
execute if score minecraft:husbandry/leash_all_frog_variants bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:husbandry/leash_all_frog_variants
execute if score blazeandcave:animal/ram bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/ram
execute if score blazeandcave:animal/loud_and_proud bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/loud_and_proud
execute if score blazeandcave:animal/battle_of_the_bands bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/battle_of_the_bands
execute if score blazeandcave:animal/caprymphony bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/caprymphony
execute if score blazeandcave:animal/animal_kingdom bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/animal_kingdom

execute if score blazeandcave:biomes/cargo_carrier bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:biomes/cargo_carrier
execute if score blazeandcave:biomes/flipper bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:biomes/flipper

execute if score blazeandcave:adventure/undying_fandom bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/undying_fandom
execute if score blazeandcave:adventure/allayance bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/allayance
execute if score minecraft:husbandry/allay_deliver_item_to_player bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:husbandry/allay_deliver_item_to_player
execute if score blazeandcave:adventure/evelyn_evergreen bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/evelyn_evergreen
execute if score blazeandcave:adventure/budget_vex bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/budget_vex
execute if score blazeandcave:adventure/diagon_allay bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/diagon_allay
execute if score minecraft:husbandry/allay_deliver_cake_to_note_block bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:husbandry/allay_deliver_cake_to_note_block
execute if score blazeandcave:adventure/awards_ceremony bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/awards_ceremony

execute if score blazeandcave:monsters/now_thats_a_lot_of_damage bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:monsters/now_thats_a_lot_of_damage
execute if score blazeandcave:monsters/blind_stare bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:monsters/blind_stare
execute if score blazeandcave:monsters/stealth_is_optional bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:monsters/stealth_is_optional
execute if score blazeandcave:monsters/warden_frostbite bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:monsters/warden_frostbite
execute if score blazeandcave:monsters/not_afraid_of_heights bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:monsters/not_afraid_of_heights
execute if score blazeandcave:monsters/house_of_freaks bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:monsters/house_of_freaks

execute if score blazeandcave:enchanting/like_a_ninja bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:enchanting/like_a_ninja
execute if score blazeandcave:enchanting/silent_but_deadly bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:enchanting/silent_but_deadly

execute if score blazeandcave:nether/hung_drawn_and_bartered bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:nether/hung_drawn_and_bartered

execute if score blazeandcave:end/the_void_frogs bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:end/the_void_frogs

execute if score blazeandcave:challenges/farlander bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:challenges/farlander

# The following advancements were added in version 1.15
execute if score blazeandcave:adventure/nerds_never_die bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/nerds_never_die
execute if score blazeandcave:adventure/and_make_it_double bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/and_make_it_double
execute if score blazeandcave:building/living_dummy bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:building/living_dummy
execute if score blazeandcave:building/built_on_sand_set_in_stone bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:building/built_on_sand_set_in_stone
execute if score blazeandcave:farming/hot_chocolate bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:farming/hot_chocolate
execute if score blazeandcave:animal/silence_of_the_lambs bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/silence_of_the_lambs
execute if score blazeandcave:animal/its_high_noon bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/its_high_noon
execute if score blazeandcave:weaponry/spleaf bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:weaponry/spleaf
execute if score blazeandcave:weaponry/there_it_goes bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:weaponry/there_it_goes
execute if score blazeandcave:end/unending_hell bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:end/unending_hell

execute if score blazeandcave:adventure/totally_not_terraria bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/totally_not_terraria

# The following advancements were added in version 1.16
execute if score blazeandcave:redstone/calibration_sensation bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:redstone/calibration_sensation

execute if score blazeandcave:building/hanging_around bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:building/hanging_around
execute if score blazeandcave:building/sign_off bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:building/sign_off
execute if score blazeandcave:building/shelf_expression bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:building/shelf_expression
execute if score blazeandcave:building/bamboozled bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:building/bamboozled
execute if score blazeandcave:building/cherry_bomb bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:building/cherry_bomb

execute if score blazeandcave:animal/desert_rider bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/desert_rider
execute if score blazeandcave:animal/hump_day bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/hump_day
execute if score blazeandcave:animal/the_high_road bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/the_high_road

execute if score blazeandcave:biomes/pretty_in_pink bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:biomes/pretty_in_pink

execute if score blazeandcave:adventure/brushed_away bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/brushed_away
execute if score minecraft:adventure/salvage_sherd bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:adventure/salvage_sherd
execute if score minecraft:adventure/craft_decorated_pot_using_only_sherds bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:adventure/craft_decorated_pot_using_only_sherds
execute if score blazeandcave:adventure/pottery_exhibition bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/pottery_exhibition
execute if score minecraft:husbandry/obtain_sniffer_egg bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:husbandry/obtain_sniffer_egg
execute if score blazeandcave:adventure/truffle_worm bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/truffle_worm
execute if score blazeandcave:adventure/jurassic_sniff bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/jurassic_sniff
execute if score blazeandcave:adventure/happy_trails bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/happy_trails
execute if score blazeandcave:adventure/raiders_of_the_lost_trim bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/raiders_of_the_lost_trim
execute if score blazeandcave:adventure/good_lookin_treasure bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/good_lookin_treasure
execute if score minecraft:adventure/trim_with_any_armor_pattern bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:adventure/trim_with_any_armor_pattern
execute if score blazeandcave:adventure/mold_maker bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/mold_maker
execute if score blazeandcave:adventure/coordinated_flair bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/coordinated_flair
execute if score blazeandcave:adventure/chromatic_armory bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/chromatic_armory
execute if score blazeandcave:adventure/genesis_of_the_end bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/genesis_of_the_end
execute if score blazeandcave:adventure/vexingly_hard_to_find bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/vexingly_hard_to_find
execute if score blazeandcave:adventure/the_sound_of_silence bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/the_sound_of_silence
execute if score minecraft:adventure/trim_with_all_exclusive_armor_patterns bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:adventure/trim_with_all_exclusive_armor_patterns
execute if score blazeandcave:adventure/stacked_smither bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/stacked_smither

execute if score blazeandcave:monsters/maximum_resistance bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:monsters/maximum_resistance

execute if score blazeandcave:redstone/monstrous_music bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:redstone/monstrous_music

execute if score blazeandcave:statistics/om_nom_nom bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:statistics/om_nom_nom
execute if score blazeandcave:statistics/yum_yum_yummo bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:statistics/yum_yum_yummo
execute if score blazeandcave:statistics/food_glorious_food bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:statistics/food_glorious_food
execute if score blazeandcave:statistics/loot_em bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:statistics/loot_em
execute if score blazeandcave:statistics/more_for_me bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:statistics/more_for_me
execute if score blazeandcave:statistics/i_heart_chests bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:statistics/i_heart_chests
execute if score blazeandcave:statistics/giga_xp_grinder bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:statistics/giga_xp_grinder

execute if score blazeandcave:nether/time_to_upgrade bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:nether/time_to_upgrade
execute if score blazeandcave:nether/piglin_peril bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:nether/piglin_peril

execute if score blazeandcave:challenges/poglin bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:challenges/poglin

execute if score blazeandcave:adventure/a_chiptune_relic bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/a_chiptune_relic
execute if score minecraft:husbandry/feed_snifflet bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:husbandry/feed_snifflet
execute if score minecraft:husbandry/plant_any_sniffer_seed bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:husbandry/plant_any_sniffer_seed
execute if score minecraft:adventure/read_power_of_chiseled_bookshelf bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:adventure/read_power_of_chiseled_bookshelf

execute if score nullscape:root bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only nullscape:root

execute if score minecraft:adventure/brush_armadillo bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:adventure/brush_armadillo
execute if score minecraft:husbandry/repair_wolf_armor bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:husbandry/repair_wolf_armor
execute if score minecraft:husbandry/remove_wolf_armor bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:husbandry/remove_wolf_armor
execute if score minecraft:husbandry/whole_pack bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:husbandry/whole_pack

# The following advancements were added in version 1.17
execute if score blazeandcave:mining/grate_expectations bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:mining/grate_expectations

execute if score blazeandcave:building/bulbous bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:building/bulbous
execute if score minecraft:adventure/lighten_up bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:adventure/lighten_up

execute if score blazeandcave:animal/farmadillo bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/farmadillo
execute if score blazeandcave:animal/armadoggo bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/armadoggo
execute if score blazeandcave:animal/paw_patrol bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/paw_patrol

execute if score minecraft:adventure/minecraft_trials_edition bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:adventure/minecraft_trials_edition
execute if score blazeandcave:adventure/this_will_be_a_breeze bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/this_will_be_a_breeze
execute if score blazeandcave:adventure/break_wind bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/break_wind
execute if score minecraft:adventure/who_needs_rockets bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:adventure/who_needs_rockets
execute if score blazeandcave:adventure/breeze_suppressor bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/breeze_suppressor
execute if score blazeandcave:adventure/from_under_your_feet bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/from_under_your_feet
execute if score minecraft:adventure/blowback bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:adventure/blowback
execute if score minecraft:adventure/under_lock_and_key bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:adventure/under_lock_and_key
execute if score blazeandcave:adventure/hard_mode_activated bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/hard_mode_activated
execute if score minecraft:adventure/revaulting bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:adventure/revaulting
execute if score blazeandcave:adventure/vault_hunter bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/vault_hunter
execute if score blazeandcave:adventure/keys_to_success bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/keys_to_success
execute if score blazeandcave:adventure/tricky_treasures bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/tricky_treasures
execute if score blazeandcave:adventure/omniscient bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/omniscient
execute if score blazeandcave:adventure/core_keeper bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/core_keeper
execute if score blazeandcave:adventure/a_suspicious_advancement bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/a_suspicious_advancement
execute if score blazeandcave:adventure/sus bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/sus

execute if score blazeandcave:monsters/bogged_down bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:monsters/bogged_down

execute if score blazeandcave:weaponry/nice_to_mace_you bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:weaponry/nice_to_mace_you
execute if score minecraft:adventure/overoverkill bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:adventure/overoverkill
execute if score blazeandcave:weaponry/warden_extinction bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:weaponry/warden_extinction

execute if score blazeandcave:redstone/craftception bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:redstone/craftception
execute if score minecraft:adventure/crafters_crafting_crafters bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:adventure/crafters_crafting_crafters
execute if score blazeandcave:redstone/factorio bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:redstone/factorio
execute if score blazeandcave:redstone/we_have_liftoff bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:redstone/we_have_liftoff

execute if score blazeandcave:enchanting/mace_windu bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:enchanting/mace_windu
execute if score blazeandcave:enchanting/whack_a_mole bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:enchanting/whack_a_mole
execute if score blazeandcave:enchanting/master_macerator bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:enchanting/master_macerator

execute if score blazeandcave:potion/imbued_projectiles bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:potion/imbued_projectiles
execute if score blazeandcave:potion/secret_of_the_ooze bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:potion/secret_of_the_ooze
execute if score blazeandcave:potion/final_shout bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:potion/final_shout

execute if score blazeandcave:end/divers_dozen bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:end/divers_dozen
execute if score blazeandcave:end/dimension_penetration bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:end/dimension_penetration

execute if score blazeandcave:challenges/overwarden bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:challenges/overwarden


execute if score blazeandcave:biomes/eyeball_forest bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:biomes/eyeball_forest
execute if score blazeandcave:biomes/heart_breaker bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:biomes/heart_breaker
execute if score blazeandcave:biomes/pale_in_comparison bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:biomes/pale_in_comparison
execute if score blazeandcave:biomes/resinance bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:biomes/resinance
execute if score blazeandcave:biomes/fake_copper bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:biomes/fake_copper

execute if score blazeandcave:building/pale_gardener bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:building/pale_gardener

execute if score blazeandcave:animal/flamboyant_range bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/flamboyant_range

execute if score blazeandcave:nether/light_show bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:nether/light_show

execute if score blazeandcave:mining/i_yearned_for_the_mines bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:mining/i_yearned_for_the_mines


execute if score blazeandcave:farming/booshes bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:farming/booshes
execute if score blazeandcave:farming/you_cant_take_the_sky_from_me bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:farming/you_cant_take_the_sky_from_me
execute if score blazeandcave:farming/certified_spud_chomper bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:farming/certified_spud_chomper

execute if score blazeandcave:animal/piglets_big_advancement bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/piglets_big_advancement
execute if score blazeandcave:animal/the_three_little_pigs bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/the_three_little_pigs
execute if score blazeandcave:animal/beef_moover bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/beef_moover
execute if score blazeandcave:animal/omelette bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/omelette
execute if score blazeandcave:animal/chick_buffet bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/chick_buffet

execute if score minecraft:adventure/heart_transplanter bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:adventure/heart_transplanter
execute if score blazeandcave:biomes/le_creak_cest_chic bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:biomes/le_creak_cest_chic

execute if score blazeandcave:adventure/all_around_the_world bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:adventure/all_around_the_world

execute if score blazeandcave:monsters/look_out bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:monsters/look_out
execute if score blazeandcave:monsters/absolute_cinema bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:monsters/absolute_cinema

execute if score blazeandcave:redstone/splatfest bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:redstone/splatfest

execute if score blazeandcave:enchanting/oh_baby_a_triple bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:enchanting/oh_baby_a_triple

execute if score blazeandcave:statistics/test_flight bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:statistics/test_flight
execute if score blazeandcave:statistics/who_needs_elytra bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:statistics/who_needs_elytra
execute if score blazeandcave:statistics/big_blimp_enthusiast bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:statistics/big_blimp_enthusiast

execute if score minecraft:husbandry/place_dried_ghast_in_water bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:husbandry/place_dried_ghast_in_water
execute if score blazeandcave:nether/snow_cone bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:nether/snow_cone
execute if score blazeandcave:nether/hot_air_balloon bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:nether/hot_air_balloon
execute if score blazeandcave:nether/midport_village bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:nether/midport_village
execute if score blazeandcave:nether/lead_zeppelin bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:nether/lead_zeppelin
execute if score blazeandcave:nether/pillow_fight bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:nether/pillow_fight
execute if score blazeandcave:nether/collateral_damage bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:nether/collateral_damage

execute if score blazeandcave:potion/string_shot bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:potion/string_shot

execute if score blazeandcave:end/why_do_i_hear_boss_music bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:end/why_do_i_hear_boss_music
execute if score blazeandcave:end/unstoppable_force_vs_immovable_object bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:end/unstoppable_force_vs_immovable_object
execute if score blazeandcave:end/youre_doing_it_wrong bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:end/youre_doing_it_wrong

execute if score blazeandcave:challenges/at_the_rim_of_the_sky bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:challenges/at_the_rim_of_the_sky
execute if score blazeandcave:challenges/lets_take_it_up_a_notch bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:challenges/lets_take_it_up_a_notch


execute if score blazeandcave:mining/copper_age bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:mining/copper_age
execute if score blazeandcave:mining/copper_golem_overlord bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:mining/copper_golem_overlord
execute if score blazeandcave:mining/beep_bop bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:mining/beep_bop
execute if score blazeandcave:mining/wax_treatment bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:mining/wax_treatment
execute if score blazeandcave:mining/total_copout bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:mining/total_copout
execute if score blazeandcave:mining/such_a_poser bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:mining/such_a_poser
execute if score blazeandcave:mining/statue_of_limitations bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:mining/statue_of_limitations
execute if score blazeandcave:mining/conductive_conglomerate bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:mining/conductive_conglomerate
execute if score blazeandcave:mining/d_b_copper bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:mining/d_b_copper
execute if score blazeandcave:mining/life_sentence bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:mining/life_sentence
execute if score blazeandcave:mining/chain_gang bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:mining/chain_gang
execute if score blazeandcave:mining/gratest_of_all_time bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:mining/gratest_of_all_time
execute if score blazeandcave:mining/green_lanterns bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:mining/green_lanterns
execute if score blazeandcave:mining/copper_computer bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:mining/copper_computer
execute if score blazeandcave:mining/school_of_hard_knocks bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:mining/school_of_hard_knocks

execute if score blazeandcave:building/chartreuse bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:building/chartreuse
execute if score blazeandcave:building/shelfception bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:building/shelfception
execute if score blazeandcave:building/locked_and_loaded bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:building/locked_and_loaded

execute if score blazeandcave:enchanting/echidna bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:enchanting/echidna


execute if score minecraft:adventure/spear_many_mobs bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:adventure/spear_many_mobs


execute if score blazeandcave:mining/mitosis bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:mining/mitosis
execute if score blazeandcave:mining/punching_bag bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:mining/punching_bag
execute if score blazeandcave:mining/truly_an_all_purpose_tool bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:mining/truly_an_all_purpose_tool
execute if score minecraft:husbandry/uh_oh bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only minecraft:husbandry/uh_oh
execute if score blazeandcave:mining/stink_bomb bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:mining/stink_bomb
execute if score blazeandcave:mining/all_the_balls bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:mining/all_the_balls
execute if score blazeandcave:mining/bouncy_beats bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:mining/bouncy_beats

execute if score blazeandcave:building/the_smell_of_rotten_eggs bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:building/the_smell_of_rotten_eggs
execute if score blazeandcave:building/cinnabar_island bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:building/cinnabar_island

execute if score blazeandcave:animal/whole_horse bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/whole_horse
execute if score blazeandcave:animal/counting_sheep bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/counting_sheep
execute if score blazeandcave:animal/fountain_of_youth bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:animal/fountain_of_youth

execute if score blazeandcave:monsters/grim_neigh bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:monsters/grim_neigh
execute if score blazeandcave:monsters/lancelot bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:monsters/lancelot
execute if score blazeandcave:monsters/sands_the_skeleton bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:monsters/sands_the_skeleton
execute if score blazeandcave:monsters/unwanted_passenger bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:monsters/unwanted_passenger
execute if score blazeandcave:monsters/ride_or_dry bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:monsters/ride_or_dry
execute if score blazeandcave:monsters/the_wicked_witch_of_the_west bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:monsters/the_wicked_witch_of_the_west

execute if score blazeandcave:weaponry/time_to_hunt bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:weaponry/time_to_hunt
execute if score blazeandcave:weaponry/spear_fishing bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:weaponry/spear_fishing
execute if score blazeandcave:weaponry/toasted_marshmallow bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:weaponry/toasted_marshmallow
execute if score blazeandcave:weaponry/britney_spears bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:weaponry/britney_spears
execute if score blazeandcave:weaponry/hit_and_run bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:weaponry/hit_and_run
execute if score blazeandcave:weaponry/arrow_of_ultimate_obliteration bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:weaponry/arrow_of_ultimate_obliteration
execute if score blazeandcave:weaponry/impiled bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:weaponry/impiled
execute if score blazeandcave:weaponry/death_star bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:weaponry/death_star

execute if score blazeandcave:biomes/welcome_to_neverland bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:biomes/welcome_to_neverland
execute if score blazeandcave:biomes/equiangular_spiral bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:biomes/equiangular_spiral
execute if score blazeandcave:biomes/a_scute_off_the_old_shell bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:biomes/a_scute_off_the_old_shell
execute if score blazeandcave:biomes/naughtylus bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:biomes/naughtylus
execute if score blazeandcave:biomes/coralful_shell bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:biomes/coralful_shell
execute if score blazeandcave:biomes/submarine_fleet bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:biomes/submarine_fleet
execute if score blazeandcave:biomes/20_leagues_under_the_sea bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:biomes/20_leagues_under_the_sea

execute if score blazeandcave:enchanting/classic_cartoon_comedy bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:enchanting/classic_cartoon_comedy
execute if score blazeandcave:enchanting/master_jouster bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:enchanting/master_jouster

execute if score blazeandcave:statistics/shell_testing bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:statistics/shell_testing
execute if score blazeandcave:statistics/captain_nemo bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:statistics/captain_nemo
execute if score blazeandcave:statistics/lord_helix bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:statistics/lord_helix

execute if score blazeandcave:potion/water_balloon bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:potion/water_balloon

execute if score blazeandcave:end/taking_the_scenic_route bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:end/taking_the_scenic_route

execute if score blazeandcave:monsters/jockey_jamboree bac_obtained_blue matches 1.. run advancement grant @a[team=bac_team_blue] only blazeandcave:monsters/jockey_jamboree
