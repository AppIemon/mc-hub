# Grants trophies to every player who is online that has never manually had trophies granted before

execute as @a at @s unless score @s bac_trophy_given matches 1 run function blazeandcave:config/grant_trophies

function blazeandcave:config

tellraw @s {"color":"green","translate":"모두에게 트로피를 지급했습니다"}
execute if entity @p[scores={bac_trophy_given=1}] run tellraw @s {"color":"red","translate":"몇몇 플레이어는 트로피를 받지 못했습니다. 이 커맨드를 사용해서 수동으로 트로피 지급을 활성화해주세요"}
execute if entity @p[scores={bac_trophy_given=1}] run tellraw @s {"color":"gray","text":"/scoreboard players set <Player's Name> bac_trophy_given 0","click_event":{"action":"suggest_command","command":"/scoreboard players set <Player's Name> bac_trophy_given 0"},"hover_event":{"action":"show_text","value":["",{"translate":"클릭하여 복사","color":"gold"}]}}

scoreboard players set @a bac_trophy_given 1