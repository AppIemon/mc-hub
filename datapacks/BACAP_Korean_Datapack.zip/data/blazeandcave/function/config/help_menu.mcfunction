tellraw @s {"text":"                                             ","color":"dark_gray","strikethrough":true}
tellraw @s {"color":"gray","bold":false,"text":" ","extra":[{"color":"gray","bold":false,"translate":"도움 메뉴"}]}

tellraw @s {"text":"                                             ","color":"dark_gray","strikethrough":true}

# Link to Config Menu Documentation
tellraw @s ["",{"text":"[ »» ]","color":"green","click_event":{"action":"open_url","url":"http://bit.ly/3HXkft2"},"hover_event":{"action":"show_text","value":["",{"translate":"클릭하여 링크 열기","color":"gold"}]}}," ",{"translate":"설정 메뉴 설명서"}]

# How to update to newer versions of the datapack
tellraw @s ["",{"text":"[ »» ]","color":"yellow","click_event":{"action":"run_command","command":"/function blazeandcave:config/help_new_version_update"},"hover_event":{"action":"show_text","value":["",{"translate":"클릭하여 보기","color":"gold"}]}}," ",{"translate":"새 데이터팩 버전으로 업데이트 하는 방법"}]

# How to add players to teams
tellraw @s ["",{"text":"[ »» ]","color":"aqua","click_event":{"action":"run_command","command":"/function blazeandcave:config/help_teams"},"hover_event":{"action":"show_text","value":["",{"translate":"클릭하여 보기","color":"gold"}]}}," ",{"translate":"플레이어를 팀에 추가하는 방법"}]

# Link to more links
## Specifically: Language Pack, Hardcore and Terralith versions, Advancements Documentation, Trophy List, Discord and Patreon
tellraw @s ["",{"text":"[ »» ]","color":"dark_green","click_event":{"action":"run_command","command":"/function blazeandcave:config/help_links"},"hover_event":{"action":"show_text","value":["",{"translate":"클릭하여 보기","color":"gold"}]}}," ",{"translate":"중요 링크"}]

# Known troubleshooting issues and FAQ's
## Specifically: Use the right version of BACAP for the right version of MC, Paper/Spigot server issues, Advancement Info
tellraw @s ["",{"text":"[ »» ]","color":"red","click_event":{"action":"run_command","command":"/function blazeandcave:config/help_troubleshooting"},"hover_event":{"action":"show_text","value":["",{"translate":"클릭하여 보기","color":"gold"}]}}," ",{"translate":"오류가 생겼을 때"}]
tellraw @s ["",{"text":"[ »» ]","color":"blue","click_event":{"action":"run_command","command":"/function blazeandcave:config/help_faq"},"hover_event":{"action":"show_text","value":["",{"translate":"클릭하여 보기","color":"gold"}]}}," ",{"translate":"자주 묻는 질문"}]


# Go back
tellraw @s {"text":"                                             ","color":"dark_gray","strikethrough":true}
tellraw @s ["",{"text":"[ «« ]","color":"red","click_event":{"action":"run_command","command":"/function blazeandcave:config"},"hover_event":{"action":"show_text","value":["",{"translate":"클릭하여 돌아가기","color":"gold"}]}}," ",{"translate":"메인 메뉴로 돌아가기"}]

tellraw @s {"text":"                                             ","color":"dark_gray","strikethrough":true}
