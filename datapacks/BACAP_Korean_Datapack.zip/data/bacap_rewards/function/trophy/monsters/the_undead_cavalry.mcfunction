give @s diamond_helmet[custom_name={"translate":"쿵쿵이 순경의 투구","color":"#39a1be","bold":true,"italic":false},lore=[{"translate":"그는 이 별명이 멋있다고 생각하겠지만,","color":"#39a1be"},{"translate":"사실 그의 말이 쿵쿵거리며 다니기 때문에 붙여진 것이랍니다","color":"#39a1be"},{"text":" "},{"translate":"과제 달성 보상","color":"gray"},{"translate":"묵시록의 기사","color":"#75E1FF","italic":false}],custom_model_data={floats:[131]},custom_data={Trophy:1b},enchantment_glint_override=true,!attribute_modifiers] 1

tellraw @s [{"text":" +1 ","color":"gold"},{"translate":"쿵쿵이 순경의 투구"}]
