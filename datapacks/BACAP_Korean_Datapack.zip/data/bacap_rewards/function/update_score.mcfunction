function blazeandcave:config/update_score
